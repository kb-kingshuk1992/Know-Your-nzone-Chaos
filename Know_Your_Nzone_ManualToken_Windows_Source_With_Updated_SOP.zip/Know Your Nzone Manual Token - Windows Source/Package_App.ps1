$ErrorActionPreference = "Stop"
$root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$spec = Join-Path $root "misc\developer_build_files\Know Your Nzone Manual Token.spec"
$dist = Join-Path $root "Final App - Ready"
$work = Join-Path $root "misc\developer_build_files\build"
py (Join-Path $root "misc\developer_build_files\embed_sop.py")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
New-Item -ItemType Directory -Path $dist -Force | Out-Null
py -m PyInstaller --noconfirm --clean --distpath $dist --workpath $work $spec
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$exe = Join-Path $dist "Know Your Nzone Manual Token\Know Your Nzone Manual Token.exe"
if (-not (Test-Path -LiteralPath $exe)) { throw "Packaged EXE was not created." }
Write-Output $exe
