from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "sop_assets"
OUTPUT = ROOT / "Know_Your_Nzone_Manual_Token_SOP.docx"
TEAL, DARK, PALE, AMBER, RED_PALE, GRID = "087F78", "142334", "EAF6F4", "FFF3D6", "FDECEA", "D7E1E8"


def font(size, bold=False):
    choices = [
        Path("C:/Windows/Fonts/seguisb.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
    ]
    for choice in choices:
        if choice.exists():
            return ImageFont.truetype(str(choice), size)
    return ImageFont.load_default()


def round_rect(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def create_extract_illustration():
    path = ASSETS / "00_extract_zip.png"
    image = Image.new("RGB", (1400, 760), "#F3F6F8")
    draw = ImageDraw.Draw(image)
    round_rect(draw, (35, 35, 1365, 725), 18, "white", "#CBD5E1", 3)
    draw.rectangle((35, 35, 1365, 90), fill="#E8EDF2")
    draw.text((60, 50), "File Explorer - Downloads", font=font(24, True), fill="#1F2937")
    draw.ellipse((43, 98, 97, 152), fill="#087F78")
    draw.text((70, 125), "1", font=font(34, True), fill="white", anchor="mm")
    draw.text((120, 103), "Right-click the ZIP file", font=font(28, True), fill="#142334")
    round_rect(draw, (75, 175, 600, 360), 14, "#F8FAFC", "#9FB3C8", 2)
    draw.rectangle((110, 215, 170, 285), fill="#F7C948", outline="#A56600", width=2)
    for y in range(220, 282, 13):
        draw.line((140, y, 140, y + 8), fill="#6B4F00", width=3)
    draw.text((195, 217), "Know Your Nzone_ManualToken.zip", font=font(25, True), fill="#142334")
    draw.text((195, 260), "Compressed (zipped) folder", font=font(21), fill="#64748B")
    round_rect(draw, (390, 300, 645, 510), 10, "white", "#94A3B8", 2)
    for index, item in enumerate(("Open", "Copy", "Extract All...", "Properties")):
        y = 320 + index * 44
        if item == "Extract All...":
            draw.rectangle((402, y - 5, 633, y + 34), fill="#DDF3F0")
        draw.text((420, y), item, font=font(21, item == "Extract All..."), fill="#142334")
    draw.line((680, 320, 780, 320), fill="#087F78", width=8)
    draw.polygon([(780, 320), (750, 298), (750, 342)], fill="#087F78")
    draw.ellipse((795, 98, 849, 152), fill="#087F78")
    draw.text((822, 125), "2", font=font(34, True), fill="white", anchor="mm")
    draw.text((870, 103), "Open the extracted folder", font=font(28, True), fill="#142334")
    round_rect(draw, (815, 175, 1315, 510), 14, "#F8FAFC", "#9FB3C8", 2)
    draw.rectangle((855, 220, 925, 275), fill="#58A6FF", outline="#2563EB", width=2)
    draw.text((950, 223), "Know Your Nzone - Manual Token", font=font(24, True), fill="#142334")
    draw.line((855, 305, 1270, 305), fill="#D7E1E8", width=2)
    round_rect(draw, (855, 335, 920, 405), 12, "#087F78")
    draw.text((887, 370), "N", font=font(34, True), fill="white", anchor="mm")
    draw.text((945, 342), "Know Your Nzone Manual Token.exe", font=font(23, True), fill="#142334")
    draw.text((945, 382), "Double-click this application", font=font(21), fill="#64748B")
    round_rect(draw, (170, 590, 1230, 675), 14, "#FFF3D6", "#E1A600", 2)
    draw.text((700, 632), "Do not run the EXE from inside the ZIP.", font=font(28, True), fill="#7A4B00", anchor="mm")
    image.save(path)
    return path


def create_console_illustration():
    path = ASSETS / "00_keep_window_open.png"
    image = Image.new("RGB", (1400, 760), "#F3F6F8")
    draw = ImageDraw.Draw(image)
    round_rect(draw, (80, 70, 1320, 650), 14, "#111827", "#64748B", 3)
    draw.rectangle((80, 70, 1320, 125), fill="#E5E7EB")
    draw.text((110, 85), "Know Your Nzone Manual Token.exe", font=font(23, True), fill="#111827")
    for index, colour in enumerate(("#EF4444", "#F59E0B", "#22C55E")):
        draw.ellipse((1210 + index * 28, 86, 1228 + index * 28, 104), fill=colour)
    for index, line in enumerate(("* Serving Flask app 'app'", "* Debug mode: off", "* Running on http://127.0.0.1:8786", "Press CTRL+C to quit")):
        draw.text((125, 175 + index * 52), line, font=font(24), fill="#D1FAE5")
    round_rect(draw, (260, 440, 1140, 560), 16, "#3B1515", "#EF4444", 3)
    draw.text((700, 480), "KEEP THIS WINDOW OPEN", font=font(38, True), fill="#FCA5A5", anchor="mm")
    draw.text((700, 530), "Closing it stops the app and all downloads.", font=font(25), fill="white", anchor="mm")
    image.save(path)
    return path


def set_run_font(run, name="Aptos", size=10.5, bold=False, color=DARK):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)


def shade_cell(cell, fill):
    properties = cell._tc.get_or_add_tcPr()
    shading = properties.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        properties.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_border(cell, colour=GRID):
    properties = cell._tc.get_or_add_tcPr()
    borders = properties.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        properties.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        element = OxmlElement(f"w:{edge}")
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "5")
        element.set(qn("w:color"), colour)
        borders.append(element)


def prevent_row_split(row):
    properties = row._tr.get_or_add_trPr()
    if properties.find(qn("w:cantSplit")) is None:
        properties.append(OxmlElement("w:cantSplit"))


def add_page_field(paragraph):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instruction = OxmlElement("w:instrText")
    instruction.set(qn("xml:space"), "preserve")
    instruction.text = " PAGE "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instruction, end])
    set_run_font(run, size=8.5, color="64748B")


def add_callout(document, title, text, fill=PALE, title_color=TEAL):
    table = document.add_table(rows=1, cols=1)
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    set_cell_border(cell, title_color)
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_before = Pt(5)
    paragraph.paragraph_format.space_after = Pt(5)
    set_run_font(paragraph.add_run(title + " "), bold=True, color=title_color)
    set_run_font(paragraph.add_run(text))
    document.add_paragraph().paragraph_format.space_after = Pt(0)


def add_steps(document, steps):
    for number, (title, text) in enumerate(steps, start=1):
        paragraph = document.add_paragraph()
        paragraph.paragraph_format.left_indent = Inches(0.08)
        paragraph.paragraph_format.space_after = Pt(4)
        set_run_font(paragraph.add_run(f"{number}. "), bold=True, color=TEAL)
        set_run_font(paragraph.add_run(title), bold=True)
        set_run_font(paragraph.add_run(f" - {text}"))


def add_picture(document, path, caption, width=6.8):
    paragraph = document.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.keep_together = True
    paragraph.paragraph_format.line_spacing = 1
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(2)
    shape = paragraph.add_run().add_picture(str(path), width=Inches(width))
    shape._inline.docPr.set("descr", caption)
    cap = document.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(5)
    set_run_font(cap.add_run(caption), size=8.5, color="64748B")


def add_picture_pair(document, left_path, right_path, caption, width=2.75):
    paragraph = document.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.keep_together = True
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(2)
    left = paragraph.add_run().add_picture(str(left_path), width=Inches(width))
    left._inline.docPr.set("descr", "Windows Properties before selecting Unblock")
    paragraph.add_run("     ")
    right = paragraph.add_run().add_picture(str(right_path), width=Inches(width))
    right._inline.docPr.set("descr", "Windows Properties after selecting Unblock")
    cap = document.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(5)
    set_run_font(cap.add_run(caption), size=8.5, color="64748B")


def add_table(document, headers, rows, widths):
    table = document.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for index, value in enumerate(headers):
        table.rows[0].cells[index].text = value
    for values in rows:
        cells = table.add_row().cells
        for index, value in enumerate(values):
            cells[index].text = value
    for row_index, row in enumerate(table.rows):
        prevent_row_split(row)
        for col_index, cell in enumerate(row.cells):
            cell.width = widths[col_index]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            shade_cell(cell, TEAL if row_index == 0 else (PALE if row_index % 2 == 0 else "FFFFFF"))
            set_cell_border(cell)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(2)
                paragraph.paragraph_format.space_after = Pt(2)
                for run in paragraph.runs:
                    set_run_font(run, size=9.2, bold=row_index == 0, color="FFFFFF" if row_index == 0 else DARK)
    document.add_paragraph().paragraph_format.space_after = Pt(0)


def add_page_heading(document, text):
    heading = document.add_heading(text, level=1)
    heading.paragraph_format.page_break_before = True
    heading.paragraph_format.keep_with_next = False
    return heading


ASSETS.mkdir(parents=True, exist_ok=True)
extract_image = create_extract_illustration()
console_image = create_console_illustration()
required = [
    "01_start_session.png",
    "02_session_ready.png",
    "03_single_customer.png",
    "04_manual_state_fallback.png",
    "05_bulk_upload.png",
    "06_usage_reports.png",
    "07_exe_properties_menu.png",
    "08_unblock_before.png",
    "09_unblock_after.png",
]
missing = [name for name in required if not (ASSETS / name).exists()]
if missing:
    raise FileNotFoundError(f"Missing SOP screenshots: {', '.join(missing)}")

document = Document()
section = document.sections[0]
section.page_width, section.page_height = Inches(8.5), Inches(11)
section.top_margin = section.bottom_margin = Inches(0.55)
section.left_margin = section.right_margin = Inches(0.72)

normal = document.styles["Normal"]
normal.font.name = "Aptos"
normal._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Aptos")
normal._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Aptos")
normal.font.size = Pt(10.5)
normal.paragraph_format.space_after = Pt(5)
normal.paragraph_format.line_spacing = 1.04

for style_name, size, colour in (("Title", 27, DARK), ("Heading 1", 18, DARK), ("Heading 2", 13, TEAL)):
    style = document.styles[style_name]
    style.font.name = "Aptos Display"
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Aptos Display")
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Aptos Display")
    style.font.size = Pt(size)
    style.font.bold = True
    style.font.color.rgb = RGBColor.from_string(colour)
    style.paragraph_format.keep_with_next = style_name != "Heading 1"
    style.paragraph_format.space_before = Pt(7)
    style.paragraph_format.space_after = Pt(5)

footer_table = section.footer.add_table(rows=1, cols=2, width=Inches(7.0))
left = footer_table.cell(0, 0).paragraphs[0]
set_run_font(left.add_run("Know Your Nzone - Manual Token | Internal use"), size=8.5, color="64748B")
right = footer_table.cell(0, 1).paragraphs[0]
right.alignment = WD_ALIGN_PARAGRAPH.RIGHT
set_run_font(right.add_run("Page "), size=8.5, color="64748B")
add_page_field(right)

document.add_paragraph("Know Your Nzone - Manual Token", style="Title")
subtitle = document.add_paragraph()
set_run_font(subtitle.add_run("Screenshot Based Standard Operating Procedure"), size=15, bold=True, color=TEAL)
document.add_paragraph("For authorised users processing customer or unloading latitude-longitude to Nzone. No Python installation and no Client ID entry are required.")
add_callout(document, "Golden rule:", "Unzip first, start the EXE, and keep the black application window open until every Excel download is finished.", AMBER, "9A6500")
document.add_heading("The full process at a glance", level=1)
add_table(document, ["1. Unzip", "2. Start", "3. Sign in", "4. Process", "5. Download"], [["Extract All", "Open the EXE", "Paste today's token", "Single or bulk", "Save XLSX outputs"]], [Inches(1.38)] * 5)
document.add_heading("Five rules that prevent almost every problem", level=1)
for rule in (
    "Never open the EXE while it is still inside the ZIP file.",
    "Never close the black application window while using the browser app.",
    "Use the current token from the authorised official email; paste the token only, not the Client ID.",
    "For bulk processing, do not rename, remove, or rearrange the template columns.",
    "Download the result before closing the app. Closing the EXE clears the token from memory.",
):
    paragraph = document.add_paragraph(style="List Bullet")
    set_run_font(paragraph.add_run(rule))
document.add_heading("What you need", level=1)
add_table(document, ["Required", "Details"], [
    ["Windows laptop", "Internet access and permission to run the supplied EXE."],
    ["App ZIP", "Know Your Nzone_ManualToken.zip received from the authorised sender."],
    ["Today's token", "Latest Mappls access token from official Outlook email."],
    ["Input", "Customer ID, Customer Name, Latitude, Longitude; State is normally automatic."],
], [Inches(1.7), Inches(5.2)])

add_page_heading(document, "Step 1 - Extract the ZIP")
add_picture(document, extract_image, "Illustration: extract the ZIP, then open the extracted folder.")
add_steps(document, [("Save the ZIP", "Put the received ZIP in Downloads or another normal folder."), ("Extract it", "Right-click the ZIP and select Extract All. Accept the suggested destination."), ("Open the new folder", "Make sure you can see Know Your Nzone Manual Token.exe.")])
add_callout(document, "Check:", "The address bar should show a normal folder path. It must not say Compressed Folder or show the ZIP as the open location.")

add_page_heading(document, "Step 2 - Start the app and leave it running")
add_picture(document, console_image, "Illustration: the black application window must remain open.")
add_steps(document, [("Double-click the EXE", "Open Know Your Nzone Manual Token.exe."), ("Wait", "The black window starts the local app; the browser normally opens automatically."), ("Keep it open", "Minimise the black window if needed, but do not close it."), ("If the browser does not open", "Open Chrome or Edge and enter http://127.0.0.1:8786.")])
add_callout(document, "Why this matters:", "The browser is only the screen. The EXE is the engine. If the black window closes, the page and Excel downloads stop working.", RED_PALE, "B42318")

add_page_heading(document, "Step 3 - Start the manual-token session")
add_picture(document, ASSETS / "01_start_session.png", "Actual app screen: session details are required at every start.", 6.55)
add_steps(document, [("Employee ID", "Enter your official employee ID."), ("Full Name", "Enter your full name as it should appear in reports."), ("Use Case", "Select one of the three approved use cases listed below."), ("Access Token", "Paste today's token received through official email. Do not enter a Client ID."), ("Start Session", "Click the green button and wait for Session ready.")])
add_callout(document, "Token safety:", "The token stays only in the running app memory. It is not saved to the laptop and is cleared when the app closes.")

add_page_heading(document, "Step 4 - Confirm the user and select the right use case")
add_picture(document, ASSETS / "02_session_ready.png", "Actual app screen: confirm Session ready and the Active user line.", 6.55)
add_table(document, ["Use Case", "Select it when"], [
    ["Non-Trade Team - Lat/Lon Based Nzone", "The Non-Trade team is converting supplied latitude-longitude to Nzone."],
    ["FleetX - Customer Lat/Lon to Nzone", "FleetX coordinates represent the customer location."],
    ["FleetX - Unloading Lat/Lon to Nzone", "FleetX coordinates represent the unloading location."],
], [Inches(3.0), Inches(3.9)])
add_callout(document, "Check before processing:", "The top-right badge must say Session ready. The Active user line must show your Employee ID, Full Name, and chosen Use Case.", AMBER, "9A6500")

add_page_heading(document, "Step 5A - Process one customer")
add_picture(document, ASSETS / "03_single_customer.png", "Actual app screen: enter the four mandatory customer fields; State Name is normally blank.", 6.35)
add_steps(document, [("Select Single customer", "Use this mode for one coordinate pair."), ("Enter four fields", "Customer ID, Customer Name, Lat, and Lon are mandatory."), ("Leave State Name blank", "The app first identifies the state automatically from the coordinates."), ("Add Customer", "Review the row that appears in the Batch section."), ("Fetch Nzones", "Click only after checking the ID, name, latitude, and longitude."), ("Download Results", "When complete, save the XLSX result.")])
add_callout(document, "Coordinate check:", "Latitude must be between -90 and 90. Longitude must be between -180 and 180. A swapped or mistyped value can point to the wrong location.")

add_page_heading(document, "Step 5B - If the app asks for the State")
add_picture(document, ASSETS / "04_manual_state_fallback.png", "Actual app screen: Manual state required is highlighted in the row.", 6.55)
add_steps(document, [("Read the remark", "Confirm the row says Manual state required."), ("Check Lat and Lon", "Correct any typing or swapped-coordinate error first."), ("Enter the State", "Type the correct state in the highlighted State box."), ("Retry", "Click Fetch Nzones again for the corrected row."), ("Escalate if still unresolved", "Preserve the output and share the row details with the authorised support owner.")])
add_callout(document, "Do not guess:", "Use the actual state for the coordinate. A wrong manual state can query the wrong Nzone layer.", RED_PALE, "B42318")

add_page_heading(document, "Step 6 - Process a bulk Excel file")
add_picture(document, ASSETS / "05_bulk_upload.png", "Actual app screen: bulk upload uses the supplied XLSX template.", 6.35)
add_steps(document, [("Select Multiple/Bulk customers", "This changes only the entry method; validation and output remain the same."), ("Download Template", "Open the downloaded XLSX and keep the column names unchanged."), ("Complete the file", "Fill Customer ID, Customer Name, Lat, and Lon. State Name is optional fallback."), ("Choose File and Upload Excel", "Select the completed XLSX and review the loaded row count."), ("Optional map review", "Use View Batch Map to spot obviously misplaced coordinates."), ("Fetch Nzones", "Keep the browser and black application window open until processing finishes."), ("Resolve and download", "Fix Manual state required rows, retry them, then download the XLSX result.")])
add_callout(document, "Recommended batch size:", "There is no fixed app row limit. For easier monitoring and recovery, use about 250 to 500 rows per file. Larger files take longer because requests run sequentially.", AMBER, "9A6500")

add_page_heading(document, "Step 7 - Download outputs and reports")
add_picture(document, ASSETS / "06_usage_reports.png", "Actual app screen: Usage and Reports provides the admin trend workbook.", 6.55)
add_table(document, ["Button", "What it downloads"], [
    ["Download Results", "Current run in XLSX format."],
    ["Download History", "Successful customer mappings stored on this laptop."],
    ["Download Admin Trend Report", "Summary, time trend, state, use-case, user, and customer-level audit sheets."],
], [Inches(2.25), Inches(4.65)])
add_callout(document, "Audit fields:", "Result, history, and customer-level admin outputs include Employee ID, Full Name, and Use Case.")
document.add_heading("Meaning of common statuses", level=2)
add_table(document, ["Status", "Action"], [
    ["Success", "Download the result. The mapping is recorded in local history."],
    ["Manual state required", "Enter the correct state in the highlighted row and retry."],
    ["Error", "Read the row message; correct input, token, connectivity, or API issue, then retry."],
    ["Re-hit blocked", "The Customer ID was previously successful, so another paid hit was prevented."],
], [Inches(2.0), Inches(4.9)])

add_page_heading(document, "Troubleshooting Windows file block")
document.add_paragraph("Use these steps when double-clicking the EXE does not open the application, especially after receiving the ZIP through email or downloading it from a shared location.")
add_picture(document, ASSETS / "07_exe_properties_menu.png", "Right-click Know Your Nzone Manual Token.exe and select Properties.", 6.35)
add_steps(document, [
    ("Return to the extracted folder", "Do not perform these steps while viewing the EXE inside the ZIP file."),
    ("Right-click the EXE", "Select Know Your Nzone Manual Token.exe in the extracted folder."),
    ("Open Properties", "Choose Properties from the right-click menu."),
])
add_callout(document, "If Properties is not visible:", "Select Show more options, then choose Properties.", AMBER, "9A6500")

add_page_heading(document, "Remove the Windows file block")
add_picture_pair(
    document,
    ASSETS / "08_unblock_before.png",
    ASSETS / "09_unblock_after.png",
    "Left: the downloaded EXE is blocked. Right: select Unblock before applying the change.",
)
add_steps(document, [
    ("Stay on the General tab", "Look at the Security message near the bottom of the Properties window."),
    ("Select Unblock", "Tick the Unblock checkbox when Windows says the file came from another computer and might be blocked."),
    ("Apply the change", "Click Apply, then click OK."),
    ("Start the app again", "Double-click the EXE and keep the black application window open."),
])
add_callout(document, "If Unblock is not shown:", "The file is not blocked using this Windows setting. Close Properties and continue with the troubleshooting table on the next page.")

add_page_heading(document, "Troubleshooting and safe closing")
add_table(document, ["Problem", "What to do"], [
    ["EXE does not open after download", "Right-click the EXE, open Properties, select Unblock if shown, click Apply and OK, then retry."],
    ["Browser says 127.0.0.1 refused to connect", "The EXE is not running. Return to the extracted folder and start it again."],
    ["Browser did not open", "Keep the EXE running and enter http://127.0.0.1:8786 in Chrome or Edge."],
    ["Session required", "Enter Employee ID, Full Name, Use Case, and today's access token."],
    ["Token rejected or expired", "Click Change Session and paste the latest token from official email."],
    ["Manual state required", "Check coordinates, enter the correct state, and retry."],
    ["Excel download cannot connect", "Confirm the black EXE window is still open, return to the app page, and download again."],
    ["Large batch is taking time", "Do not close either window. Use 250-500 row files for future runs."],
], [Inches(2.35), Inches(4.55)])
document.add_heading("Close in the correct order", level=1)
add_steps(document, [("Finish all downloads", "Open the saved XLSX if necessary to confirm it is complete."), ("Close the browser tab", "The page is no longer needed."), ("Close the black application window", "This stops the local app and clears the token from memory.")])
add_callout(document, "Final reminder:", "Share the ZIP or full extracted folder with users as instructed by the process owner. Never distribute a folder containing your own token, output files, or local history.", RED_PALE, "B42318")

document.save(OUTPUT)
print(OUTPUT)
