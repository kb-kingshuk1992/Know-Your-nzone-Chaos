const tokenState = document.querySelector("#tokenState");
const tokenDate = document.querySelector("#tokenDate");
const apiTokenState = document.querySelector("#apiTokenState");
const changeSessionBtn = document.querySelector("#changeSessionBtn");
const sessionModal = document.querySelector("#sessionModal");
const sessionForm = document.querySelector("#sessionForm");
const employeeId = document.querySelector("#employeeId");
const fullName = document.querySelector("#fullName");
const useCase = document.querySelector("#useCase");
const accessToken = document.querySelector("#accessToken");
const sessionError = document.querySelector("#sessionError");
const adminSettingsBtn = document.querySelector("#adminSettingsBtn");
const adminModal = document.querySelector("#adminModal");
const closeAdminBtn = document.querySelector("#closeAdminBtn");
const costBasis = document.querySelector("#costBasis");
const panIndiaCost = document.querySelector("#panIndiaCost");
const stateCostRows = document.querySelector("#stateCostRows");
const layerState = document.querySelector("#layerState");
const singleModeBtn = document.querySelector("#singleModeBtn");
const bulkModeBtn = document.querySelector("#bulkModeBtn");
const singlePanel = document.querySelector("#singlePanel");
const bulkPanel = document.querySelector("#bulkPanel");
const singleForm = document.querySelector("#singleForm");
const singleCustomerId = document.querySelector("#singleCustomerId");
const singleCustomerName = document.querySelector("#singleCustomerName");
const singleStateName = document.querySelector("#singleStateName");
const singleLat = document.querySelector("#singleLat");
const singleLon = document.querySelector("#singleLon");
const uploadForm = document.querySelector("#uploadForm");
const fileInput = document.querySelector("#fileInput");
const batchRows = document.querySelector("#batchRows");
const batchSummary = document.querySelector("#batchSummary");
const processBtn = document.querySelector("#processBtn");
const mapBtn = document.querySelector("#mapBtn");
const downloadResults = document.querySelector("#downloadResults");
const message = document.querySelector("#message");
const mapModal = document.querySelector("#mapModal");
const closeMapBtn = document.querySelector("#closeMapBtn");
const mapDetails = document.querySelector("#mapDetails");

let customers = [];
let results = [];
let map;
let sessionReady = false;

async function apiJson(url, options = {}) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Request failed.");
  return payload;
}

async function refreshTokenStatus() {
  const status = await apiJson("/api/token-status");
  tokenDate.textContent = `Today: ${status.today}`;
  const layerReady = Number(status.state_layer_count || 0) > 0;
  const boundaryReady = Number(status.state_boundary_count || 0) > 0;
  const tokenLabel = status.session_configured
    ? `Active user: ${status.employee_id} - ${status.full_name}. Use case: ${status.use_case}.`
    : "Session not started. Enter Employee ID, Full Name, Use Case, and Access Token.";
  layerState.textContent = layerReady && boundaryReady
    ? `${status.state_boundary_count} state/UT boundaries and ${status.state_layer_count} Nzone layer mappings loaded.`
    : "State boundaries or Nzone layer mappings are missing or unreadable.";
  apiTokenState.textContent = tokenLabel;
  const ready = status.session_configured && status.has_token && layerReady && boundaryReady;
  sessionReady = ready;
  tokenState.textContent = ready ? "Session ready" : status.session_configured ? "State data required" : "Session required";
  tokenState.className = ready ? "pill ok" : "pill warn";
  processBtn.disabled = !customers.length || !ready;
  sessionModal.classList.toggle("hidden", status.session_configured);
  renderCostSummary(status.mtd_cost_summary);
}

sessionForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  sessionError.classList.add("hidden");
  try {
    await apiJson("/api/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        employee_id: employeeId.value,
        full_name: fullName.value,
        use_case: useCase.value,
        access_token: accessToken.value,
      }),
    });
    accessToken.value = "";
    sessionModal.classList.add("hidden");
    await refreshTokenStatus();
    showMessage("Session started. Employee ID, Full Name, and Use Case will be added to all downloads.", "success");
  } catch (error) {
    sessionError.textContent = error.message;
    sessionError.classList.remove("hidden");
  }
});

changeSessionBtn.addEventListener("click", async () => {
  await apiJson("/api/session/clear", { method: "POST" });
  sessionReady = false;
  employeeId.value = "";
  fullName.value = "";
  useCase.value = "";
  accessToken.value = "";
  sessionModal.classList.remove("hidden");
  await refreshTokenStatus();
});

function showMessage(text, type = "info") {
  message.textContent = text;
  message.className = `message ${type}`;
}

function clearMessage() {
  message.className = "message hidden";
  message.textContent = "";
}

function renderRows(rows) {
  if (!rows.length) {
    batchRows.innerHTML = '<tr><td colspan="11" class="empty">Upload the filled Excel template to begin.</td></tr>';
    return;
  }

  batchRows.innerHTML = rows
    .map((row, index) => {
      const status = row.status || (row.valid ? "Ready" : "Invalid");
      const statusClass = status === "Success" || status === "Ready" ? "status-ok" : "status-error";
      const manualStateRequired = Boolean(row.manual_state_required) || status === "Manual state required";
      const stateCell = manualStateRequired
        ? `<input class="manual-state-input" data-row-index="${index}" type="text" value="${escapeHtml(row.manual_state_override ? row.state_name || "" : "")}" placeholder="Enter state and retry" aria-label="Manual state for ${escapeHtml(row.customer_id)}" />`
        : escapeHtml(row.state_name || "");
      return `
        <tr>
          <td>${escapeHtml(row.customer_id)}</td>
          <td>${escapeHtml(row.customer_name)}</td>
          <td>${stateCell}</td>
          <td>${escapeHtml(row.state_identification || "")}</td>
          <td>${escapeHtml(row.lat ?? "")}</td>
          <td>${escapeHtml(row.lon ?? "")}</td>
          <td>${escapeHtml(row.dataset_source || "")}</td>
          <td>${escapeHtml(row.nzone_code || "")}</td>
          <td>${escapeHtml(row.nzone_name || "")}</td>
          <td>${escapeHtml(row.remark || "")}</td>
          <td><span class="${statusClass}">${escapeHtml(status)}</span>${row.error ? `<div class="error-text">${escapeHtml(row.error)}</div>` : ""}</td>
        </tr>
      `;
    })
    .join("");

  batchRows.querySelectorAll(".manual-state-input").forEach((input) => {
    input.addEventListener("input", (event) => {
      const index = Number(event.target.dataset.rowIndex);
      const stateName = event.target.value.trim();
      if (!customers[index]) customers[index] = { ...rows[index] };
      customers[index] = {
        ...customers[index],
        state_name: stateName,
        manual_state_override: Boolean(stateName),
        manual_state_required: !stateName,
      };
      results = [];
      disableDownload();
    });
  });
}

function updateBatchControls() {
  const validLocations = customers.filter((row) => isFinite(row.lat) && isFinite(row.lon));
  batchSummary.textContent = customers.length
    ? `${customers.length} row(s) loaded, ${validLocations.length} with valid coordinates.`
    : "No file uploaded.";
  mapBtn.disabled = !validLocations.length;
  processBtn.disabled = !customers.length || !sessionReady;
  refreshTokenStatus().catch(() => {});
}

function enableDownload(url) {
  downloadResults.href = url;
  downloadResults.classList.remove("disabled");
}

function disableDownload() {
  downloadResults.href = "#";
  downloadResults.classList.add("disabled");
}

singleModeBtn.addEventListener("click", () => setEntryMode("single"));
bulkModeBtn.addEventListener("click", () => setEntryMode("bulk"));
adminSettingsBtn.addEventListener("click", () => {
  adminModal.classList.remove("hidden");
  refreshTokenStatus().catch(() => {});
});
closeAdminBtn.addEventListener("click", () => {
  adminModal.classList.add("hidden");
});
adminModal.addEventListener("click", (event) => {
  if (event.target === adminModal) adminModal.classList.add("hidden");
});

function renderCostSummary(summary) {
  if (!summary) return;
  costBasis.textContent = `1 hit = ${Number(summary.cost_per_hit_inr || 0).toFixed(2)} INR | MTD ${summary.month || ""}`;
  panIndiaCost.textContent = `${summary.total_hits || 0} hits | INR ${Number(summary.total_cost_inr || 0).toFixed(2)}`;

  const states = summary.states || [];
  if (!states.length) {
    stateCostRows.innerHTML = '<div class="empty">No successful hits this month.</div>';
    return;
  }

  stateCostRows.innerHTML = states
    .map((row) => `
      <div class="cost-row">
        <span>${escapeHtml(row.state_name)}</span>
        <strong>${escapeHtml(row.hits)} hits</strong>
        <strong>INR ${Number(row.cost_inr || 0).toFixed(2)}</strong>
      </div>
    `)
    .join("");
}

function setEntryMode(mode) {
  const isSingle = mode === "single";
  singleModeBtn.classList.toggle("active", isSingle);
  bulkModeBtn.classList.toggle("active", !isSingle);
  singlePanel.classList.toggle("hidden", !isSingle);
  bulkPanel.classList.toggle("hidden", isSingle);
}

singleForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();
  disableDownload();

  try {
    const payload = await apiJson("/api/customer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer_id: singleCustomerId.value,
        customer_name: singleCustomerName.value,
        state_name: singleStateName.value,
        lat: singleLat.value,
        lon: singleLon.value,
      }),
    });
    customers = [payload.customer];
    results = [];
    renderRows(customers);
    updateBatchControls();
    showMessage("Single customer loaded. Review the row, then fetch Nzone.", payload.customer.valid ? "success" : "error");
  } catch (error) {
    showMessage(error.message, "error");
  }
});

uploadForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();
  disableDownload();

  if (!fileInput.files.length) {
    showMessage("Choose an Excel file first.", "error");
    return;
  }

  const body = new FormData();
  body.append("file", fileInput.files[0]);

  try {
    const payload = await apiJson("/api/upload", { method: "POST", body });
    customers = payload.customers;
    results = [];
    renderRows(customers);
    updateBatchControls();
    showMessage("Excel file loaded. Review the rows, then fetch Nzones.", "success");
  } catch (error) {
    showMessage(error.message, "error");
  }
});

processBtn.addEventListener("click", async () => {
  clearMessage();
  processBtn.disabled = true;
  processBtn.textContent = "Fetching";
  try {
    const payload = await apiJson("/api/process", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ customers }),
    });
    results = payload.results;
    customers = payload.results.map((row) => ({ ...row }));
    renderRows(results);
    enableDownload(payload.download_url);
    showProcessSummary(results);
  } catch (error) {
    showMessage(error.message, "error");
  } finally {
    processBtn.textContent = "Fetch Nzones";
    updateBatchControls();
  }
});

function showProcessSummary(rows) {
  const successCount = rows.filter((row) => row.status === "Success").length;
  const rehitCount = rows.filter((row) => row.status === "Re-hit blocked").length;
  const errorCount = rows.filter((row) => row.status === "Error").length;
  const manualCount = rows.filter((row) => row.status === "Manual state required").length;
  const summary = `Nzone lookup completed: ${successCount} success, ${errorCount} API/input error, ${rehitCount} re-hit blocked. Download the Excel result for details.`;
  const manualText = manualCount ? ` ${manualCount} row(s) need a manual state before retry.` : "";
  showMessage(`${summary}${manualText}`, errorCount || manualCount ? "error" : "success");
}

mapBtn.addEventListener("click", () => {
  openMap();
});

closeMapBtn.addEventListener("click", () => {
  mapModal.classList.add("hidden");
});

mapModal.addEventListener("click", (event) => {
  if (event.target === mapModal) mapModal.classList.add("hidden");
});

function openMap() {
  mapModal.classList.remove("hidden");
  setTimeout(() => {
    const rows = results.length ? results : customers;
    const points = rows.filter((row) => isFinite(row.lat) && isFinite(row.lon));
    if (!map) {
      map = L.map("map");
      L.tileLayer("https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}", {
        maxZoom: 20,
        attribution: "Google road tiles",
      }).addTo(map);
    }
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker) map.removeLayer(layer);
    });

    const bounds = [];
    points.forEach((row) => {
      const marker = L.marker([row.lat, row.lon], { icon: customerIcon(row) }).addTo(map);
      marker.bindPopup(`
        <strong>${escapeHtml(row.customer_id)}</strong><br>
        ${escapeHtml(row.customer_name || "")}<br>
        ${escapeHtml(customerClassification(row).label)}<br>
        State: ${escapeHtml(row.state_name || "")}<br>
        Lat: ${escapeHtml(row.lat)}<br>
        Lon: ${escapeHtml(row.lon)}<br>
        Nzone: ${escapeHtml(row.nzone_code || "Not fetched")}
      `);
      marker.on("click", () => renderMapDetails(row));
      bounds.push([row.lat, row.lon]);
    });

    renderMapDetails(points[0]);
    map.invalidateSize();
    if (bounds.length === 1) {
      map.setView(bounds[0], 13);
    } else if (bounds.length > 1) {
      map.fitBounds(bounds, { padding: [30, 30] });
    }
  }, 50);
}

function customerClassification(row) {
  const id = String(row.customer_id || "").trim();
  if (id.startsWith("1")) {
    return { label: "Dealer counter", className: "dealer", symbol: "&#9733;" };
  }
  if (id.startsWith("2")) {
    return { label: "Retailer counter", className: "retailer", symbol: "" };
  }
  return { label: "Unclassified customer", className: "unknown", symbol: "" };
}

function customerIcon(row) {
  const classification = customerClassification(row);
  const html =
    classification.className === "dealer"
      ? `<span class="marker-symbol">${classification.symbol}</span>`
      : "";
  return L.divIcon({
    className: `customer-marker ${classification.className}`,
    html,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    popupAnchor: [0, -12],
  });
}

function renderMapDetails(row) {
  if (!row) {
    mapDetails.innerHTML = `
      <p class="eyebrow">Customer Details</p>
      <h3>Select a marker</h3>
      <p class="muted">Click a customer point to view customer classification and Nzone geography.</p>
    `;
    return;
  }

  const classification = customerClassification(row);
  mapDetails.innerHTML = `
    <p class="eyebrow">Customer Details</p>
    <div class="detail-heading">
      <h3>${escapeHtml(row.customer_id)}</h3>
      <span class="class-pill ${classification.className}">${escapeHtml(classification.label)}</span>
    </div>
    <p class="customer-name">${escapeHtml(row.customer_name || "")}</p>
    <dl>
      <dt>Latitude</dt><dd>${escapeHtml(row.lat ?? "")}</dd>
      <dt>Longitude</dt><dd>${escapeHtml(row.lon ?? "")}</dd>
      <dt>State</dt><dd>${escapeHtml(row.state_name || "Not provided")}</dd>
      <dt>API Layer</dt><dd>${escapeHtml(row.dataset_source || "Not resolved")}</dd>
      <dt>Nzone Code</dt><dd>${escapeHtml(row.nzone_code || "Not fetched")}</dd>
      <dt>Nzone City</dt><dd>${escapeHtml(row.city || "Not fetched")}</dd>
      <dt>Nzone Taluka</dt><dd>${escapeHtml(row.taluka || "Not fetched")}</dd>
      <dt>Nzone District</dt><dd>${escapeHtml(row.district || "Not fetched")}</dd>
      <dt>Nzone Area</dt><dd>${escapeHtml(row.nzone_area || "Not fetched")}</dd>
      <dt>Nzone Type</dt><dd>${escapeHtml(row.nzone_type || "Not fetched")}</dd>
      <dt>Nzone Subtype</dt><dd>${escapeHtml(row.nzone_subtype || "Not fetched")}</dd>
    </dl>
  `;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

refreshTokenStatus().catch(() => {
  tokenState.textContent = "Server unavailable";
  tokenState.className = "pill warn";
});
