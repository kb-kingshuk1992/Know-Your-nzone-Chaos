from __future__ import annotations

import unittest
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

from openpyxl import Workbook, load_workbook

import app


class KnowYourNzoneTests(unittest.TestCase):
    def tearDown(self) -> None:
        for key in app.SESSION_CONTEXT:
            app.SESSION_CONTEXT[key] = ""

    def test_session_requires_employee_name_use_case_and_token(self) -> None:
        client = app.app.test_client()
        rejected = client.post("/api/session", json={"full_name": "Test User"})
        self.assertEqual(rejected.status_code, 400)

        response = client.post(
            "/api/session",
            json={
                "employee_id": "E123",
                "full_name": "Test User",
                "use_case": app.USE_CASES[0],
                "access_token": "a" * 40,
            },
        )
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["session_configured"])
        self.assertEqual(payload["employee_id"], "E123")
        self.assertNotIn("access_token", payload)

    def test_macos_frozen_build_uses_application_support_for_writable_data(self) -> None:
        expected = Path.home() / "Library" / "Application Support" / "Know Your Nzone Manual Token"
        with (
            patch.object(app, "IS_FROZEN", True),
            patch.object(app.sys, "platform", "darwin"),
            patch.dict(app.os.environ, {"KNOW_YOUR_NZONE_DATA_DIR": ""}, clear=False),
        ):
            self.assertEqual(app.resolve_writable_root(), expected)

    def test_data_directory_can_be_overridden_on_any_platform(self) -> None:
        override = str((app.APP_DIR / "portable-data").resolve())
        with patch.dict(app.os.environ, {"KNOW_YOUR_NZONE_DATA_DIR": override}, clear=True):
            self.assertEqual(app.resolve_writable_root(), Path(override))

    def test_manual_sop_is_available_from_the_ux(self) -> None:
        client = app.app.test_client()
        page = client.get("/")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"Manual Token SOP", page.data)

        response = client.get("/api/user-guide")
        try:
            self.assertEqual(response.status_code, 200)
            self.assertIn("Know_Your_Nzone_Manual_Token_SOP.docx", response.headers.get("Content-Disposition", ""))
        finally:
            response.close()

    def test_embedded_sop_downloads_as_the_original_docx(self) -> None:
        source = Path(__file__).resolve().parents[1] / "Know_Your_Nzone_Manual_Token_SOP.docx"
        client = app.app.test_client()
        with patch.object(app, "USER_GUIDE_FILE", source.with_name("missing-sop.docx")):
            response = client.get("/api/user-guide")
        try:
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data, source.read_bytes())
            self.assertIn("Know_Your_Nzone_Manual_Token_SOP.docx", response.headers.get("Content-Disposition", ""))
        finally:
            response.close()

    def test_process_requires_active_session(self) -> None:
        response = app.app.test_client().post("/api/process", json={"customers": [{}]})
        self.assertEqual(response.status_code, 400)
        self.assertIn("Employee ID", response.get_json()["error"])

    def test_process_adds_session_identity_to_result_and_ledger(self) -> None:
        app.SESSION_CONTEXT.update(
            {
                "employee_id": "E123",
                "full_name": "Test User",
                "use_case": app.USE_CASES[0],
                "access_token": "a" * 40,
            }
        )
        saved_ledger = {}

        def capture_ledger(value: dict) -> None:
            saved_ledger.update(value)

        submitted = {
            "customer_id": "99123",
            "customer_name": "Test",
            "lat": 26.9124,
            "lon": 75.7873,
        }
        with (
            patch.object(app, "read_hit_ledger", return_value={}),
            patch.object(app, "write_hit_ledger", side_effect=capture_ledger),
            patch.object(app, "write_results_workbook", return_value=app.ROOT / "fake.xlsx"),
            patch.object(app, "call_mappls_with_token_refresh", return_value={"src_sap_nzone": "NZ1"}),
        ):
            response = app.app.test_client().post("/api/process", json={"customers": [submitted]})

        self.assertEqual(response.status_code, 200)
        result = response.get_json()["results"][0]
        self.assertEqual(result["employee_id"], "E123")
        self.assertEqual(result["full_name"], "Test User")
        self.assertEqual(result["use_case"], app.USE_CASES[0])
        self.assertEqual(saved_ledger["99123"]["employee_id"], "E123")

    def test_coordinate_state_detection_uses_layer_workbook_names(self) -> None:
        cases = [
            (26.9124, 75.7873, "RAJASTHAN", "north_rajasthan_nzone_v0"),
            (28.6139, 77.2090, "DELHI", "north_delhi_nzone"),
            (34.1526, 77.5771, "LADAKH", "north_ladakh_nzone"),
            (21.2514, 81.6296, "CHATTISGARH", "east_chattisgarh_nzone"),
        ]
        for index, (lat, lon, expected_state, expected_layer) in enumerate(cases, start=1):
            with self.subTest(state=expected_state):
                customer = app.normalize_customer(
                    index,
                    {
                        "Customer ID": str(index),
                        "Customer Name": expected_state,
                        "Lat": lat,
                        "Lon": lon,
                    },
                )
                self.assertTrue(customer["valid"])
                self.assertEqual(customer["state_name"], expected_state)
                self.assertEqual(customer["dataset_source"], expected_layer)
                self.assertEqual(customer["state_identification"], "Automatic from coordinates")

    def test_manual_state_is_requested_when_coordinates_do_not_match(self) -> None:
        customer = app.normalize_customer(
            1,
            {"Customer ID": "1", "Customer Name": "Outside", "Lat": 0, "Lon": 0},
        )
        self.assertFalse(customer["valid"])
        self.assertTrue(customer["manual_state_required"])
        self.assertIn("Enter the state manually", customer["remark"])

        fallback = app.normalize_customer(
            1,
            {
                "Customer ID": "1",
                "Customer Name": "Outside",
                "Lat": 0,
                "Lon": 0,
                "State Name": "RAJASTHAN",
                "Manual State Override": True,
            },
        )
        self.assertTrue(fallback["valid"])
        self.assertEqual(fallback["dataset_source"], "north_rajasthan_nzone_v0")
        self.assertEqual(fallback["state_identification"], "Manual fallback")

    def test_xlsx_upload_does_not_require_state_column(self) -> None:
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(["Customer ID", "Customer Name", "Lat", "Lon"])
        sheet.append(["100", "Test", 26.9124, 75.7873])
        stream = BytesIO()
        workbook.save(stream)
        stream.seek(0)

        customers = app.read_customers_from_excel(stream)
        self.assertEqual(len(customers), 1)
        self.assertEqual(customers[0]["state_name"], "RAJASTHAN")

    def test_no_nzone_enables_manual_state_retry(self) -> None:
        customer = app.normalize_customer(
            1,
            {"Customer ID": "100", "Customer Name": "Test", "Lat": 26.9124, "Lon": 75.7873},
        )
        with patch.object(app, "call_mappls_with_token_refresh", side_effect=app.NoNzoneFoundError("No Nzone found")):
            result = app.build_result(customer)
        self.assertEqual(result["status"], "Manual state required")
        self.assertTrue(result["manual_state_required"])
        self.assertIn("Enter the state manually", result["remark"])

    def test_result_download_is_xlsx_with_numeric_coordinates(self) -> None:
        result = {
            "employee_id": "E123",
            "full_name": "Test User",
            "use_case": app.USE_CASES[1],
            "customer_id": "100",
            "customer_name": "Test",
            "state_name": "RAJASTHAN",
            "state_identification": "Automatic from coordinates",
            "remark": "",
            "lat": 26.9124,
            "lon": 75.7873,
            "dataset_source": "north_rajasthan_nzone_v0",
            "status": "Success",
        }
        folder = app.ROOT / "test_output"
        folder.mkdir(exist_ok=True)
        with patch.object(app, "OUTPUT_DIR", folder):
            path = app.write_results_workbook([result])
        try:
            self.assertEqual(path.suffix, ".xlsx")
            workbook = load_workbook(path, data_only=True)
            sheet = workbook["Results"]
            headers = [cell.value for cell in sheet[1]]
            self.assertIn("State Identification", headers)
            self.assertIn("Remark", headers)
            self.assertEqual(sheet.cell(2, headers.index("Employee ID") + 1).value, "E123")
            self.assertEqual(sheet.cell(2, headers.index("Full Name") + 1).value, "Test User")
            self.assertEqual(sheet.cell(2, headers.index("Use Case") + 1).value, app.USE_CASES[1])
            self.assertIsInstance(sheet.cell(2, headers.index("Lat") + 1).value, float)
            self.assertIsInstance(sheet.cell(2, headers.index("Lon") + 1).value, float)
        finally:
            path.unlink(missing_ok=True)

    def test_admin_report_contains_user_and_use_case_audit_fields(self) -> None:
        ledger = {
            "100": {
                "employee_id": "E123",
                "full_name": "Test User",
                "use_case": app.USE_CASES[2],
                "customer_id": "100",
                "customer_name": "Test",
                "state_name": "RAJASTHAN",
                "lat": 26.9124,
                "lon": 75.7873,
                "nzone_code": "NZ1",
                "nzone_name": "Test Nzone",
                "dataset_source": "north_rajasthan_nzone_v0",
                "processed_on": "2026-09-27 10:30:00",
            }
        }
        folder = app.ROOT / "test_output"
        folder.mkdir(exist_ok=True)
        with patch.object(app, "OUTPUT_DIR", folder), patch.object(app, "read_hit_ledger", return_value=ledger):
            path = app.write_admin_report_workbook()
        try:
            workbook = load_workbook(path, data_only=True)
            self.assertIn("Use Case Wise", workbook.sheetnames)
            self.assertIn("User Wise", workbook.sheetnames)
            headers = [cell.value for cell in workbook["Successful Customers"][1]]
            self.assertEqual(headers[:3], ["Employee ID", "Full Name", "Use Case"])
        finally:
            path.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
