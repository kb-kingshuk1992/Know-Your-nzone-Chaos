# Know Your Nzone Manual Token - Windows source

This folder contains the current Windows manual-token application source and its updated illustrated SOP from the existing project. The separate `Know_Your_Nzone_ManualToken_With_Illustrated_SOP.zip` is the end-user executable distribution. It does not contain editable source files.

## Source files

- `app.py`: application server, manual-token session, automatic state identification, Nzone API calls, XLSX processing and usage reports.
- `static/index.html`, `static/app.js`, `static/styles.css`: browser interface.
- `sop_payload.py`: embedded Windows SOP and state/layer workbook for the packaged EXE.
- `Know_Your_Nzone_Manual_Token_SOP.docx`: updated illustrated Windows SOP, including EXE Properties and Unblock troubleshooting.
- `misc/developer_build_files/build_manual_token_sop.py` and `sop_assets/`: SOP generation source and screenshots.
- `misc/developer_build_files/embed_sop.py`: refreshes the SOP and workbook embedded in the EXE.
- `Package_App.ps1` and the Windows `.spec`: executable build configuration.
- `tests/test_app.py`: existing project checks.

## Run or build as a developer

The existing application source is Python. Python is required by the developer who edits or rebuilds it; end users run the packaged EXE without installing Python.

From this extracted source folder on a Windows development computer with Python installed:

```powershell
py -m pip install -r requirements.txt -r requirements-build.txt
py app.py
```

To build a new Windows executable, run `Package_App.ps1` in PowerShell. It refreshes the embedded SOP and workbook before packaging. The result is under `Final App - Ready/Know Your Nzone Manual Token/`. Share the complete generated folder, zipped, with end users.

To revise the SOP, edit `build_manual_token_sop.py` or the DOCX. If using the generator, run `py misc/developer_build_files/build_manual_token_sop.py`, review the resulting DOCX, then run `Package_App.ps1` to embed the updated document.

Keep the required master CSV, state boundaries, layer workbook and static files in their supplied locations. Local data, reports and XLSX templates are created by the app as required. No personal usage history, result files or saved tokens are included in this source handoff.

This handoff uses the current project source; a historical source revision for the supplied executable ZIP was not recorded, so exact build provenance of that earlier EXE cannot be guaranteed.
