from __future__ import annotations

import csv
import json
import os
import sys
import threading
import webbrowser
from datetime import datetime
from collections import defaultdict
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from uuid import uuid4

import requests
import urllib3
from flask import Flask, jsonify, render_template, request, send_file
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

try:
    from sop_payload import LAYER_WORKBOOK_BYTES, SOP_DOCUMENT_BYTES
except ImportError:
    LAYER_WORKBOOK_BYTES = None
    SOP_DOCUMENT_BYTES = None


IS_FROZEN = bool(getattr(sys, "frozen", False))
APP_DIR = Path(sys.executable).resolve().parent if IS_FROZEN else Path(__file__).resolve().parent
ASSET_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))


def resolve_writable_root() -> Path:
    override = os.environ.get("KNOW_YOUR_NZONE_DATA_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    if IS_FROZEN and sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Know Your Nzone Manual Token"
    return APP_DIR


ROOT = resolve_writable_root()
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "output"
TEMPLATE_DIR = ROOT / "templates"
SETTINGS_FILE = DATA_DIR / "settings.json"
HIT_LEDGER_FILE = DATA_DIR / "customer_hit_ledger.json"
MASTER_FILE = ASSET_DIR / "Nozne_master_CSV_PBIX.csv"
LAYER_FILE = ASSET_DIR / "MMI Nzone Layers 2026_04_23.xlsx"
STATE_BOUNDARY_FILE = ASSET_DIR / "india_states_simplified.geojson"
USER_GUIDE_SOURCE_FILE = ASSET_DIR / "Know_Your_Nzone_Manual_Token_SOP.docx"
USER_GUIDE_FILE = USER_GUIDE_SOURCE_FILE
VERIFY_MAPPLS_SSL = False
DEFAULT_DATASET_SOURCE = "north_rajasthan_nzone_v0"
DEFAULT_PORT = 8786

if not VERIFY_MAPPLS_SSL:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_BASE_URL = "https://mgis-apiv2.mappls.com/dqv/query_apply/join"

INPUT_COLUMNS = ["Customer ID", "Customer Name", "Lat", "Lon", "State Name"]
REQUIRED_INPUT_COLUMNS = ["Customer ID", "Customer Name", "Lat", "Lon"]
OUTPUT_COLUMNS = [
    "Employee ID",
    "Full Name",
    "Use Case",
    "Customer ID",
    "Customer Name",
    "State Name",
    "State Identification",
    "Remark",
    "Lat",
    "Lon",
    "Dataset Source",
    "Nzone Code",
    "Nzone ID",
    "Nzone Name",
    "State",
    "District",
    "Taluka",
    "City",
    "Postal Code",
    "Nzone Area",
    "Nzone Type",
    "Nzone Subtype",
    "Status",
    "Processed On",
    "Error",
]

HISTORY_COLUMNS = [
    "Employee ID",
    "Full Name",
    "Use Case",
    "Customer ID",
    "Customer Name",
    "State Name",
    "Lat",
    "Lon",
    "Nzone Code",
    "Nzone Name",
    "Processed On",
]

HIT_COST_INR = 0.10
USE_CASES = [
    "Non-Trade Team - Lat/Lon Based Nzone",
    "FleetX - Customer Lat/Lon to Nzone",
    "FleetX - Unloading Lat/Lon to Nzone",
]
SESSION_CONTEXT = {"access_token": "", "employee_id": "", "full_name": "", "use_case": ""}

app = Flask(__name__, template_folder="static", static_folder="static")


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)


def today_key() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def session_is_configured() -> bool:
    return all(SESSION_CONTEXT.get(key) for key in ("access_token", "employee_id", "full_name", "use_case"))


def session_public_status() -> dict[str, Any]:
    return {
        "session_configured": session_is_configured(),
        "has_token": bool(SESSION_CONTEXT.get("access_token")),
        "employee_id": SESSION_CONTEXT.get("employee_id", ""),
        "full_name": SESSION_CONTEXT.get("full_name", ""),
        "use_case": SESSION_CONTEXT.get("use_case", ""),
        "use_cases": USE_CASES,
    }


def read_settings() -> dict[str, str]:
    if not SETTINGS_FILE.exists():
        return {"dataset_source": DEFAULT_DATASET_SOURCE}
    try:
        settings = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(settings, dict):
            return {"dataset_source": DEFAULT_DATASET_SOURCE}
        dataset_source = str(settings.get("dataset_source") or DEFAULT_DATASET_SOURCE).strip()
        return {"dataset_source": dataset_source}
    except json.JSONDecodeError:
        return {"dataset_source": DEFAULT_DATASET_SOURCE}


def save_settings(dataset_source: str) -> dict[str, str]:
    ensure_dirs()
    settings = {"dataset_source": dataset_source.strip()}
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    return settings


def get_dataset_source() -> str:
    return read_settings()["dataset_source"]


def build_api_url(dataset_source: str) -> str:
    params = {
        "queryType": "spatialOperation",
        "datasetSource": dataset_source,
        "operator": "intersects",
        "sourceProperty": "geom",
        "userGeom": "true",
    }
    return f"{API_BASE_URL}?{urlencode(params)}"


def read_hit_ledger() -> dict[str, Any]:
    if not HIT_LEDGER_FILE.exists():
        return {}
    try:
        data = json.loads(HIT_LEDGER_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        return {}


def write_hit_ledger(ledger: dict[str, Any]) -> None:
    ensure_dirs()
    HIT_LEDGER_FILE.write_text(json.dumps(ledger, indent=2), encoding="utf-8")


def normalize_customer_id(customer_id: Any) -> str:
    return str(customer_id or "").strip().upper()


def rehit_error(customer: dict[str, Any], message: str) -> dict[str, Any]:
    return {
        **customer,
        "status": "Re-hit blocked",
        "error": message,
    }


def parse_float(value: Any) -> float | None:
    try:
        if value is None or str(value).strip() == "":
            return None
        return float(str(value).strip())
    except ValueError:
        return None


def clean_header(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def normalize_key(value: Any) -> str:
    return " ".join(str(value or "").strip().upper().split())


def normalize_state_code(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text.zfill(2) if text.isdigit() and len(text) < 2 else text


def load_layer_mapping() -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    if LAYER_FILE.exists():
        workbook_source: Any = LAYER_FILE
    elif LAYER_WORKBOOK_BYTES is not None:
        workbook_source = BytesIO(LAYER_WORKBOOK_BYTES)
    else:
        return {}, {}, {}

    workbook = load_workbook(workbook_source, data_only=True)
    sheet = workbook.active
    headers = [clean_header(cell.value) for cell in sheet[1]]
    try:
        code_idx = headers.index("state code (as per s4)")
        state_idx = headers.index("state name (as per s4)")
        layer_idx = headers.index("nzone layer name")
    except ValueError:
        return {}, {}, {}

    by_code: dict[str, str] = {}
    by_state: dict[str, str] = {}
    state_name_by_code: dict[str, str] = {}
    for row in sheet.iter_rows(min_row=2, values_only=True):
        code = normalize_state_code(row[code_idx])
        state = normalize_key(row[state_idx])
        layer = str(row[layer_idx] or "").strip()
        if code and layer:
            by_code[code] = layer
            state_name_by_code[code] = state
        if state and layer:
            by_state[state] = layer
    return by_code, by_state, state_name_by_code


LAYER_BY_STATE_CODE, LAYER_BY_STATE_NAME, STATE_NAME_BY_CODE = load_layer_mapping()
STATE_CODE_BY_NAME = {state_name: code for code, state_name in STATE_NAME_BY_CODE.items()}
STATE_NAME_ALIASES = {
    "ANDAMAN AND NICOBAR ISLANDS": "ANDAMAN AND NICOBAR",
    "CHHATTISGARH": "CHATTISGARH",
    "DADRA AND NAGAR HAVELI AND DAMAN AND DIU": "DADRA & NAGAR HAVELI",
}


def geometry_bounds(coordinates: Any) -> tuple[float, float, float, float]:
    min_lon = min_lat = float("inf")
    max_lon = max_lat = float("-inf")

    def visit(value: Any) -> None:
        nonlocal min_lon, min_lat, max_lon, max_lat
        if (
            isinstance(value, list)
            and len(value) >= 2
            and isinstance(value[0], (int, float))
            and isinstance(value[1], (int, float))
        ):
            lon, lat = float(value[0]), float(value[1])
            min_lon, min_lat = min(min_lon, lon), min(min_lat, lat)
            max_lon, max_lat = max(max_lon, lon), max(max_lat, lat)
            return
        if isinstance(value, list):
            for item in value:
                visit(item)

    visit(coordinates)
    return min_lon, min_lat, max_lon, max_lat


def load_state_boundaries() -> list[dict[str, Any]]:
    if not STATE_BOUNDARY_FILE.exists():
        return []
    try:
        collection = json.loads(STATE_BOUNDARY_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []

    boundaries = []
    for feature in collection.get("features") or []:
        properties = feature.get("properties") or {}
        geometry = feature.get("geometry") or {}
        boundary_state_name = normalize_key(properties.get("state_name"))
        state_name = STATE_NAME_ALIASES.get(boundary_state_name, boundary_state_name)
        state_code = STATE_CODE_BY_NAME.get(state_name, "")
        if geometry.get("type") not in {"Polygon", "MultiPolygon"}:
            continue
        coordinates = geometry.get("coordinates") or []
        if not coordinates:
            continue
        boundaries.append(
            {
                "state_code": state_code,
                "state_name": state_name,
                "geometry_type": geometry.get("type"),
                "coordinates": coordinates,
                "bounds": geometry_bounds(coordinates),
            }
        )
    boundaries.sort(
        key=lambda item: (item["bounds"][2] - item["bounds"][0])
        * (item["bounds"][3] - item["bounds"][1])
    )
    return boundaries


def point_on_segment(lon: float, lat: float, start: list[float], end: list[float]) -> bool:
    x1, y1 = float(start[0]), float(start[1])
    x2, y2 = float(end[0]), float(end[1])
    cross = (lon - x1) * (y2 - y1) - (lat - y1) * (x2 - x1)
    if abs(cross) > 1e-10:
        return False
    return min(x1, x2) - 1e-10 <= lon <= max(x1, x2) + 1e-10 and min(y1, y2) - 1e-10 <= lat <= max(y1, y2) + 1e-10


def point_in_ring(lon: float, lat: float, ring: list[list[float]]) -> bool:
    inside = False
    if len(ring) < 3:
        return False
    previous = ring[-1]
    for current in ring:
        if point_on_segment(lon, lat, previous, current):
            return True
        x1, y1 = float(previous[0]), float(previous[1])
        x2, y2 = float(current[0]), float(current[1])
        if (y1 > lat) != (y2 > lat):
            intersection_lon = (x2 - x1) * (lat - y1) / (y2 - y1) + x1
            if lon < intersection_lon:
                inside = not inside
        previous = current
    return inside


def point_in_polygon(lon: float, lat: float, polygon: list[list[list[float]]]) -> bool:
    if not polygon or not point_in_ring(lon, lat, polygon[0]):
        return False
    return not any(point_in_ring(lon, lat, hole) for hole in polygon[1:])


def detect_state(lat: float, lon: float) -> dict[str, str] | None:
    for boundary in STATE_BOUNDARIES:
        min_lon, min_lat, max_lon, max_lat = boundary["bounds"]
        if not (min_lon <= lon <= max_lon and min_lat <= lat <= max_lat):
            continue
        polygons = (
            [boundary["coordinates"]]
            if boundary["geometry_type"] == "Polygon"
            else boundary["coordinates"]
        )
        if any(point_in_polygon(lon, lat, polygon) for polygon in polygons):
            return {
                "state_code": boundary["state_code"],
                "state_name": boundary["state_name"],
            }
    return None


STATE_BOUNDARIES = load_state_boundaries()


def resolve_dataset_source(state_name: Any) -> tuple[str | None, str | None]:
    name = normalize_key(state_name)
    if name and name in LAYER_BY_STATE_NAME:
        return LAYER_BY_STATE_NAME[name], None
    if not name:
        return None, "State Name is required to select the Nzone API layer"
    return None, f"No Nzone layer found for State Name '{state_name}'"


def normalize_customer(row_number: int, row: dict[str, Any]) -> dict[str, Any]:
    customer_id = str(row.get("Customer ID") or "").strip()
    customer_name = str(row.get("Customer Name") or "").strip()
    supplied_state_name = str(row.get("State Name") or row.get("state_name") or "").strip()
    manual_state_override = bool(row.get("Manual State Override") or row.get("manual_state_override"))
    lat = parse_float(row.get("Lat"))
    lon = parse_float(row.get("Lon"))
    errors = []
    state_name = ""
    state_code = ""
    state_identification = ""
    remark = ""
    dataset_source = None
    dataset_error = None

    if not customer_id:
        errors.append("Customer ID is required")
    if lat is None or not -90 <= lat <= 90:
        errors.append("Lat must be between -90 and 90")
    if lon is None or not -180 <= lon <= 180:
        errors.append("Lon must be between -180 and 180")

    location_valid = lat is not None and lon is not None and -90 <= lat <= 90 and -180 <= lon <= 180
    detected = detect_state(lat, lon) if location_valid and not manual_state_override else None
    if detected:
        state_code = detected["state_code"]
        state_name = detected["state_name"]
        dataset_source = LAYER_BY_STATE_CODE.get(state_code)
        state_identification = "Automatic from coordinates"
        if not dataset_source:
            dataset_error = f"No Nzone layer found for automatically identified state '{state_name}'"
    elif supplied_state_name:
        state_name = supplied_state_name
        dataset_source, dataset_error = resolve_dataset_source(state_name)
        state_identification = "Manual fallback"
        manual_state_override = True
        remark = "Automatic state identification was unavailable or overridden. The supplied state is being used."
    elif location_valid:
        state_identification = "Manual state required"
        remark = "State could not be identified from the coordinates. Enter the state manually and retry."
        dataset_error = "State could not be identified from the supplied coordinates"

    if dataset_error:
        errors.append(dataset_error)

    return {
        "row_number": row_number,
        "customer_id": customer_id,
        "customer_name": customer_name,
        "state_name": state_name,
        "state_code": state_code,
        "state_identification": state_identification,
        "remark": remark,
        "manual_state_override": manual_state_override,
        "manual_state_required": state_identification == "Manual state required",
        "status": "Manual state required" if state_identification == "Manual state required" else "",
        "lat": lat,
        "lon": lon,
        "dataset_source": dataset_source,
        "valid": not errors,
        "error": "; ".join(errors),
    }


def read_customers_from_excel(file_obj: Any) -> list[dict[str, Any]]:
    workbook = load_workbook(file_obj, data_only=True)
    sheet = workbook.active
    headers = [cell.value for cell in sheet[1]]
    header_map = {clean_header(value): index for index, value in enumerate(headers)}
    required_map = {clean_header(col): col for col in REQUIRED_INPUT_COLUMNS}

    missing = [label for key, label in required_map.items() if key not in header_map]
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")

    customers = []
    for excel_row in range(2, sheet.max_row + 1):
        values = [sheet.cell(excel_row, col + 1).value for col in range(len(headers))]
        if all(value in (None, "") for value in values):
            continue
        row = {}
        for key, label in required_map.items():
            row[label] = values[header_map[key]]
        state_key = clean_header("State Name")
        if state_key in header_map:
            row["State Name"] = values[header_map[state_key]]
        customers.append(normalize_customer(excel_row, row))
    return customers


def create_template_workbook() -> Path:
    ensure_dirs()
    path = TEMPLATE_DIR / "nzone_input_template.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Input"
    sheet.append(INPUT_COLUMNS)
    sheet.append(["10000001", "Sample Dealer", 27.040839, 77.464148, ""])
    sheet["E1"].comment = Comment(
        "Optional. Leave blank for automatic state identification from latitude and longitude. Use only as a manual fallback.",
        "Know Your Nzone",
    )
    style_header(sheet)
    autosize(sheet)
    workbook.save(path)
    return path


def style_header(sheet: Any) -> None:
    fill = PatternFill(fill_type="solid", fgColor="0F766E")
    for cell in sheet[1]:
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = fill


def autosize(sheet: Any) -> None:
    for column_cells in sheet.columns:
        width = max(len(str(cell.value or "")) for cell in column_cells) + 2
        sheet.column_dimensions[get_column_letter(column_cells[0].column)].width = min(max(width, 12), 34)


def load_master_by_nzone_code() -> dict[str, dict[str, Any]]:
    if not MASTER_FILE.exists():
        return {}

    lookup: dict[str, dict[str, Any]] = {}
    with MASTER_FILE.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            code = str(row.get("Transport Zone") or row.get("src_sap_nzone") or "").strip()
            if not code:
                continue
            lookup[code] = {
                "nzone_code": code,
                "nzone_name": row.get("nzone_nme") or row.get("Transport Zone Name"),
                "state": row.get("State Name"),
                "district": row.get("District name"),
                "taluka": row.get("Taluka Name"),
                "city": row.get("City Name"),
                "postal_code": row.get("Postal Code") or row.get("nzone_pin"),
                "nzone_area": row.get("nzone_area"),
                "nzone_type": row.get("nzone_type"),
                "nzone_subtype": row.get("nzone_subtype"),
            }
    return lookup


MASTER_BY_CODE = load_master_by_nzone_code()


class NoNzoneFoundError(ValueError):
    pass


def call_mappls(customer: dict[str, Any], token: str, dataset_source: str) -> dict[str, Any]:
    payload = {
        "geometry": {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "properties": {},
                    "geometry": {
                        "coordinates": [customer["lon"], customer["lat"]],
                        "type": "Point",
                    },
                }
            ],
        }
    }
    session = requests.Session()
    session.trust_env = False
    response = session.post(
        build_api_url(dataset_source),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload,
        verify=VERIFY_MAPPLS_SSL,
        timeout=30,
    )
    response.raise_for_status()
    body = response.json()
    if not body.get("success"):
        raise ValueError(body.get("message") or "Mappls API did not return success")

    data = body.get("data") or []
    if not data:
        raise NoNzoneFoundError("No Nzone found for this point")
    return data[0]


def call_mappls_with_token_refresh(customer: dict[str, Any], dataset_source: str) -> dict[str, Any]:
    token = str(SESSION_CONTEXT.get("access_token") or "").strip()
    if not token:
        raise ValueError("Start a session with a valid Mappls access token before fetching Nzones.")
    try:
        return call_mappls(customer, token, dataset_source)
    except requests.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        if status_code in {401, 403}:
            raise ValueError("The access token was rejected or has expired. Update the session token and retry.") from exc
        raise


def build_result(customer: dict[str, Any]) -> dict[str, Any]:
    result = {**customer}
    if not customer.get("valid"):
        if customer.get("manual_state_required"):
            return {
                **result,
                "status": "Manual state required",
                "remark": customer.get("remark") or "Enter the state manually and retry.",
                "error": customer.get("error", "State could not be identified"),
            }
        return {**result, "status": "Error", "error": customer.get("error", "Invalid row")}
    if not customer.get("dataset_source"):
        return {**result, "status": "Error", "error": "Dataset source is not available for this customer state"}

    try:
        api_row = call_mappls_with_token_refresh(customer, customer["dataset_source"])
        nzone_code = str(api_row.get("src_sap_nzone") or "").strip()
        master_row = MASTER_BY_CODE.get(nzone_code, {})
        return {
            **result,
            "nzone_code": nzone_code,
            "nzone_id": api_row.get("src_nzoneid"),
            "nzone_name": master_row.get("nzone_name") or api_row.get("src_nzone_nme"),
            "state": master_row.get("state") or api_row.get("src_state_name"),
            "district": master_row.get("district") or api_row.get("src_district_name"),
            "taluka": master_row.get("taluka") or api_row.get("src_taluka_name"),
            "city": master_row.get("city") or api_row.get("src_city_name"),
            "postal_code": master_row.get("postal_code") or api_row.get("src_postal_code"),
            "nzone_area": master_row.get("nzone_area") or api_row.get("src_nzone_area"),
            "nzone_type": master_row.get("nzone_type") or api_row.get("src_nzone_type"),
            "nzone_subtype": master_row.get("nzone_subtype") or api_row.get("src_nzone_subtype"),
            "status": "Success",
            "processed_on": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "error": "",
        }
    except NoNzoneFoundError as exc:
        return {
            **result,
            "status": "Manual state required",
            "manual_state_required": True,
            "remark": (
                f"The state was identified as {customer.get('state_name')}, but the Nzone API returned no Nzone. "
                "Enter the state manually and retry."
            ),
            "error": str(exc),
        }
    except requests.HTTPError as exc:
        message = exc.response.text[:300] if exc.response is not None else str(exc)
        return {**result, "status": "Error", "error": f"API HTTP error: {message}"}
    except (requests.RequestException, ValueError) as exc:
        return {**result, "status": "Error", "error": str(exc)}


def write_results_workbook(results: list[dict[str, Any]]) -> Path:
    ensure_dirs()
    path = OUTPUT_DIR / f"nzone_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Results"
    sheet.append(OUTPUT_COLUMNS)
    for result in results:
        sheet.append(
            [
                result.get("employee_id"),
                result.get("full_name"),
                result.get("use_case"),
                result.get("customer_id"),
                result.get("customer_name"),
                result.get("state_name"),
                result.get("state_identification"),
                result.get("remark"),
                result.get("lat"),
                result.get("lon"),
                result.get("dataset_source"),
                result.get("nzone_code"),
                result.get("nzone_id"),
                result.get("nzone_name"),
                result.get("state"),
                result.get("district"),
                result.get("taluka"),
                result.get("city"),
                result.get("postal_code"),
                result.get("nzone_area"),
                result.get("nzone_type"),
                result.get("nzone_subtype"),
                result.get("status"),
                result.get("processed_on"),
                result.get("error"),
            ]
        )
    style_header(sheet)
    autosize(sheet)
    workbook.save(path)
    return path


def write_history_workbook() -> Path:
    ensure_dirs()
    ledger = read_hit_ledger()
    path = OUTPUT_DIR / f"successful_customer_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Successful History"
    sheet.append(HISTORY_COLUMNS)
    for key in sorted(ledger):
        row = ledger[key]
        sheet.append(
            [
                row.get("employee_id"),
                row.get("full_name"),
                row.get("use_case"),
                row.get("customer_id"),
                row.get("customer_name"),
                row.get("state_name"),
                row.get("lat"),
                row.get("lon"),
                row.get("nzone_code"),
                row.get("nzone_name"),
                row.get("processed_on"),
            ]
        )
    style_header(sheet)
    autosize(sheet)
    workbook.save(path)
    return path


def parsed_processed_datetime(value: Any) -> datetime | None:
    try:
        return datetime.strptime(str(value), "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def add_summary_sheet(workbook: Workbook, title: str, headers: list[str], rows: list[list[Any]]) -> None:
    sheet = workbook.create_sheet(title)
    sheet.append(headers)
    for row in rows:
        sheet.append(row)
    style_header(sheet)
    autosize(sheet)


def summary_row(label: str, counts: dict[str, int]) -> list[Any]:
    total = counts.get("total", 0)
    return [
        label,
        total,
        counts.get("Dealer", 0),
        counts.get("Retailer", 0),
        counts.get("Unclassified", 0),
        round(total * HIT_COST_INR, 2),
    ]


def state_month_summary_row(state: str, month: str, counts: dict[str, int]) -> list[Any]:
    row = summary_row(month, counts)
    return [state, row[0], *row[1:]]


def write_admin_report_workbook() -> Path:
    ensure_dirs()
    ledger = read_hit_ledger()
    path = OUTPUT_DIR / f"admin_success_trend_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}.xlsx"
    workbook = Workbook()
    workbook.remove(workbook.active)

    successful_rows = []
    daily: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    weekly: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    monthly: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    statewise: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    state_monthly: dict[tuple[str, str], dict[str, int]] = defaultdict(lambda: defaultdict(int))
    use_case_wise: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    user_wise: dict[tuple[str, str], dict[str, int]] = defaultdict(lambda: defaultdict(int))

    for key in sorted(ledger):
        row = ledger[key]
        processed_at = parsed_processed_datetime(row.get("processed_on"))
        state = str(row.get("state_name") or "Unknown").strip() or "Unknown"
        employee_id = str(row.get("employee_id") or "Unknown").strip() or "Unknown"
        full_name = str(row.get("full_name") or "Unknown").strip() or "Unknown"
        use_case = str(row.get("use_case") or "Unknown").strip() or "Unknown"
        processed_on = row.get("processed_on")
        classification = customer_classification_name(row.get("customer_id"))

        if processed_at:
            day_key = processed_at.strftime("%Y-%m-%d")
            iso_year, iso_week, _ = processed_at.isocalendar()
            week_key = f"{iso_year}-W{iso_week:02d}"
            month_key = processed_at.strftime("%Y-%m")
            for bucket in (daily[day_key], weekly[week_key], monthly[month_key], state_monthly[(state, month_key)]):
                bucket["total"] += 1
                bucket[classification] += 1
        else:
            day_key = week_key = month_key = "Unknown"

        statewise[state]["total"] += 1
        statewise[state][classification] += 1
        use_case_wise[use_case]["total"] += 1
        use_case_wise[use_case][classification] += 1
        user_wise[(employee_id, full_name)]["total"] += 1
        user_wise[(employee_id, full_name)][classification] += 1
        successful_rows.append(
            [
                employee_id,
                full_name,
                use_case,
                row.get("customer_id"),
                row.get("customer_name"),
                classification,
                state,
                row.get("lat"),
                row.get("lon"),
                row.get("nzone_code"),
                row.get("nzone_name"),
                row.get("dataset_source"),
                processed_on,
                day_key,
                week_key,
                month_key,
                HIT_COST_INR,
            ]
        )

    total_hits = len(successful_rows)
    add_summary_sheet(
        workbook,
        "Report Summary",
        ["Metric", "Value"],
        [
            ["Generated On", datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
            ["Total Successful Hits", total_hits],
            ["Distinct Employees", len(user_wise)],
            ["Distinct Use Cases", len(use_case_wise)],
            ["Cost Basis", "1 hit = 0.10 INR"],
            ["Total Cost INR", round(total_hits * HIT_COST_INR, 2)],
        ],
    )
    add_summary_sheet(
        workbook,
        "Daily Trend",
        ["Date", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [summary_row(key, counts) for key, counts in sorted(daily.items())],
    )
    add_summary_sheet(
        workbook,
        "Weekly Trend",
        ["ISO Week", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [summary_row(key, counts) for key, counts in sorted(weekly.items())],
    )
    add_summary_sheet(
        workbook,
        "Monthly Trend",
        ["Month", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [summary_row(key, counts) for key, counts in sorted(monthly.items())],
    )
    add_summary_sheet(
        workbook,
        "State Wise",
        ["State", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [summary_row(key, counts) for key, counts in sorted(statewise.items())],
    )
    add_summary_sheet(
        workbook,
        "State Monthly Trend",
        ["State", "Month", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [state_month_summary_row(state, month, counts) for (state, month), counts in sorted(state_monthly.items())],
    )
    add_summary_sheet(
        workbook,
        "Use Case Wise",
        ["Use Case", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [summary_row(key, counts) for key, counts in sorted(use_case_wise.items())],
    )
    add_summary_sheet(
        workbook,
        "User Wise",
        ["Employee ID", "Full Name", "Successful Hits", "Dealers", "Retailers", "Unclassified", "Cost INR"],
        [
            [employee_id, full_name, *summary_row("", counts)[1:]]
            for (employee_id, full_name), counts in sorted(user_wise.items())
        ],
    )
    add_summary_sheet(
        workbook,
        "Successful Customers",
        [
            "Employee ID",
            "Full Name",
            "Use Case",
            "Customer ID",
            "Customer Name",
            "Customer Type",
            "State Name",
            "Lat",
            "Lon",
            "Nzone Code",
            "Nzone Name",
            "Dataset Source",
            "Processed On",
            "Day",
            "ISO Week",
            "Month",
            "Cost INR",
        ],
        successful_rows,
    )

    workbook.save(path)
    return path


def parse_processed_month(value: Any) -> str | None:
    try:
        return datetime.strptime(str(value), "%Y-%m-%d %H:%M:%S").strftime("%Y-%m")
    except (TypeError, ValueError):
        return None


def build_mtd_cost_summary() -> dict[str, Any]:
    current_month = datetime.now().strftime("%Y-%m")
    state_summary: dict[str, dict[str, Any]] = {}

    for row in read_hit_ledger().values():
        if parse_processed_month(row.get("processed_on")) != current_month:
            continue
        state = str(row.get("state_name") or "Unknown").strip() or "Unknown"
        if state not in state_summary:
            state_summary[state] = {"state_name": state, "hits": 0, "cost_inr": 0.0}
        state_summary[state]["hits"] += 1
        state_summary[state]["cost_inr"] = round(state_summary[state]["hits"] * HIT_COST_INR, 2)

    states = sorted(state_summary.values(), key=lambda item: item["state_name"])
    total_hits = sum(item["hits"] for item in states)
    return {
        "month": current_month,
        "cost_per_hit_inr": HIT_COST_INR,
        "states": states,
        "total_hits": total_hits,
        "total_cost_inr": round(total_hits * HIT_COST_INR, 2),
    }


def customer_classification_name(customer_id: Any) -> str:
    customer_id_text = str(customer_id or "").strip()
    if customer_id_text.startswith("1"):
        return "Dealer"
    if customer_id_text.startswith("2"):
        return "Retailer"
    return "Unclassified"


@app.get("/")
def index() -> str:
    return render_template("index.html")


@app.get("/api/app-info")
def app_info() -> Any:
    return jsonify({"app": "Know Your Nzone - Manual Token", "ok": True})


@app.get("/api/token-status")
def token_status() -> Any:
    return jsonify(
        {
            "today": today_key(),
            **session_public_status(),
            "token_mode": "manual_session",
            "dataset_source": get_dataset_source(),
            "state_layer_count": len(LAYER_BY_STATE_CODE),
            "state_boundary_count": len(STATE_BOUNDARIES),
            "mtd_cost_summary": build_mtd_cost_summary(),
        }
    )


@app.post("/api/session")
def configure_session() -> Any:
    payload = request.get_json(silent=True) or {}
    employee_id = str(payload.get("employee_id") or "").strip()
    full_name = str(payload.get("full_name") or "").strip()
    use_case = str(payload.get("use_case") or "").strip()
    access_token = str(payload.get("access_token") or "").strip()
    if not employee_id:
        return jsonify({"error": "Employee ID is required."}), 400
    if not full_name:
        return jsonify({"error": "Full Name is required."}), 400
    if use_case not in USE_CASES:
        return jsonify({"error": "Select one of the available use cases."}), 400
    if len(access_token) < 20:
        return jsonify({"error": "Enter a valid Mappls access token."}), 400
    SESSION_CONTEXT.update(
        {
            "employee_id": employee_id,
            "full_name": full_name,
            "use_case": use_case,
            "access_token": access_token,
        }
    )
    return jsonify({"ok": True, **session_public_status()})


@app.post("/api/session/clear")
def clear_session() -> Any:
    for key in SESSION_CONTEXT:
        SESSION_CONTEXT[key] = ""
    return jsonify({"ok": True, **session_public_status()})


@app.post("/api/settings")
def update_settings() -> Any:
    payload = request.get_json(silent=True) or {}
    dataset_source = str(payload.get("dataset_source") or "").strip()
    if not dataset_source:
        return jsonify({"error": "Dataset source is required."}), 400
    settings = save_settings(dataset_source)
    return jsonify({"ok": True, **settings})


@app.get("/api/template")
def download_template() -> Any:
    return send_file(create_template_workbook(), as_attachment=True, download_name="nzone_input_template.xlsx")


@app.get("/api/user-guide")
def download_user_guide() -> Any:
    if USER_GUIDE_FILE.exists():
        return send_file(USER_GUIDE_FILE, as_attachment=True, download_name="Know_Your_Nzone_Manual_Token_SOP.docx")
    if SOP_DOCUMENT_BYTES is not None:
        document = BytesIO(SOP_DOCUMENT_BYTES)
        return send_file(
            document,
            as_attachment=True,
            download_name="Know_Your_Nzone_Manual_Token_SOP.docx",
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    return jsonify({"error": "Manual-token SOP document not found."}), 404


@app.post("/api/upload")
def upload_excel() -> Any:
    uploaded = request.files.get("file")
    if not uploaded:
        return jsonify({"error": "Upload an Excel file."}), 400
    try:
        customers = read_customers_from_excel(uploaded)
        if not customers:
            return jsonify({"error": "No input rows found."}), 400
        return jsonify({"customers": customers})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/customer")
def add_single_customer() -> Any:
    payload = request.get_json(silent=True) or {}
    row = {
        "Customer ID": payload.get("customer_id"),
        "Customer Name": payload.get("customer_name"),
        "State Name": payload.get("state_name"),
        "Lat": payload.get("lat"),
        "Lon": payload.get("lon"),
    }
    return jsonify({"customer": normalize_customer(1, row)})


@app.post("/api/process")
def process_customers() -> Any:
    if not session_is_configured():
        return jsonify({"error": "Complete Employee ID, Full Name, Use Case, and Access Token before processing."}), 400
    payload = request.get_json(silent=True) or {}
    customers = payload.get("customers") or []
    if not isinstance(customers, list) or not customers:
        return jsonify({"error": "No customer rows to process."}), 400

    ledger = read_hit_ledger()
    successful_in_batch: set[str] = set()
    results = []

    for row_number, submitted in enumerate(customers, start=1):
        customer = normalize_customer(
            row_number,
            {
                "Customer ID": submitted.get("customer_id"),
                "Customer Name": submitted.get("customer_name"),
                "State Name": submitted.get("state_name"),
                "Lat": submitted.get("lat"),
                "Lon": submitted.get("lon"),
                "Manual State Override": submitted.get("manual_state_override"),
            },
        )
        customer.update(
            {
                "employee_id": SESSION_CONTEXT["employee_id"],
                "full_name": SESSION_CONTEXT["full_name"],
                "use_case": SESSION_CONTEXT["use_case"],
            }
        )
        customer_key = normalize_customer_id(customer.get("customer_id"))
        if customer.get("valid") and customer_key in ledger:
            previous = ledger[customer_key]
            processed_on = previous.get("processed_on") or "an earlier run"
            nzone_code = previous.get("nzone_code") or "unknown Nzone"
            results.append(
                rehit_error(
                    customer,
                    f"Re-hit blocked: customer was already processed on {processed_on} with Nzone {nzone_code}.",
                )
            )
            continue

        if customer.get("valid") and customer_key in successful_in_batch:
            results.append(rehit_error(customer, "Re-hit blocked: duplicate customer ID found in this batch."))
            continue

        result = build_result(customer)
        results.append(result)
        if result.get("status") == "Success" and customer_key:
            successful_in_batch.add(customer_key)
            ledger[customer_key] = {
                "employee_id": SESSION_CONTEXT["employee_id"],
                "full_name": SESSION_CONTEXT["full_name"],
                "use_case": SESSION_CONTEXT["use_case"],
                "customer_id": customer.get("customer_id"),
                "customer_name": customer.get("customer_name"),
                "state_name": customer.get("state_name"),
                "dataset_source": customer.get("dataset_source"),
                "lat": customer.get("lat"),
                "lon": customer.get("lon"),
                "nzone_code": result.get("nzone_code"),
                "nzone_name": result.get("nzone_name"),
                "processed_on": result.get("processed_on"),
            }

    write_hit_ledger(ledger)
    output_file = write_results_workbook(results)
    return jsonify(
        {
            "results": results,
            "download_url": f"/api/results/{output_file.name}",
        }
    )


@app.get("/api/results/<filename>")
def download_results(filename: str) -> Any:
    path = OUTPUT_DIR / filename
    if not path.exists() or path.parent != OUTPUT_DIR:
        return jsonify({"error": "Result file not found."}), 404
    return send_file(path, as_attachment=True, download_name="nzone_lookup_results.xlsx")


@app.get("/api/history")
def download_history() -> Any:
    output_file = write_history_workbook()
    return send_file(output_file, as_attachment=True, download_name="successful_customer_history.xlsx")


@app.get("/api/admin-report")
def download_admin_report() -> Any:
    output_file = write_admin_report_workbook()
    return send_file(output_file, as_attachment=True, download_name="admin_success_trend_report.xlsx")


def run_macos_desktop(port: int) -> None:
    """Run the local server with a small native macOS keep-open window."""
    try:
        import tkinter as tk
        from tkinter import ttk
    except ImportError:
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
        return

    server = threading.Thread(
        target=lambda: app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False),
        daemon=True,
    )
    server.start()

    window = tk.Tk()
    window.title("Know Your Nzone Manual Token")
    window.geometry("520x250")
    window.resizable(False, False)

    frame = ttk.Frame(window, padding=28)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Know Your Nzone is running", font=("Helvetica", 18, "bold")).pack(pady=(0, 12))
    ttk.Label(
        frame,
        text="Keep this window open while using the browser application.\nClosing it stops the app and clears the token from memory.",
        justify="center",
    ).pack(pady=(0, 20))
    ttk.Button(frame, text="Open Application", command=lambda: webbrowser.open(f"http://127.0.0.1:{port}")).pack()
    ttk.Label(frame, text=f"Local address: http://127.0.0.1:{port}", foreground="#666666").pack(pady=(16, 0))

    window.after(1200, lambda: webbrowser.open(f"http://127.0.0.1:{port}"))
    window.mainloop()


if __name__ == "__main__":
    ensure_dirs()
    port = int(os.environ.get("KNOW_YOUR_NZONE_PORT", DEFAULT_PORT))
    if IS_FROZEN and sys.platform == "darwin":
        run_macos_desktop(port)
    else:
        if IS_FROZEN:
            threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
