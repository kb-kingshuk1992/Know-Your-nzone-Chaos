'use strict';
const {app,BrowserWindow,dialog,shell}=require('electron');
const path=require('node:path');
const {createServer}=require('./server.cjs');
let backend,window;
app.setName('Know Your Nzone Manual Token');
if(!app.requestSingleInstanceLock()){app.quit();}else{
app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.focus();}});
app.whenReady().then(async()=>{
  backend=await createServer({assetDir:__dirname,dataDir:path.join(app.getPath('appData'),'Know Your Nzone Manual Token JavaScript')});
  window=new BrowserWindow({width:1400,height:950,minWidth:1000,minHeight:700,title:'Know Your Nzone Manual Token',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
  window.webContents.setWindowOpenHandler(({url})=>{if(/^https:\/\//.test(url))shell.openExternal(url);return {action:'deny'};});
  window.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith(backend.url+'/'))event.preventDefault();});
  window.webContents.session.on('will-download',(_event,item)=>{item.setSaveDialogOptions({defaultPath:path.join(app.getPath('downloads'),item.getFilename())});});
  await window.loadURL(backend.url);
  window.on('close',event=>{
    if(backend.isBusy()){
      const answer=dialog.showMessageBoxSync(window,{type:'warning',buttons:['Keep processing','Close app'],defaultId:0,cancelId:0,title:'Batch still running',message:'A batch is still processing. Closing the app stops the remaining requests.',detail:'Successful rows already completed are saved in local history.'});
      if(answer===0)event.preventDefault();
    }
  });
  window.on('closed',()=>window=null);
}).catch(e=>{dialog.showErrorBox('Know Your Nzone could not start',e.message);app.quit();});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend){backend.server.closeAllConnections();backend.server.close();}});
}
