# Know Your Nzone Manual Token for macOS

Mac desktop version of the Windows manual-token app. It supports Apple Silicon MacBooks, including MacBook Neo A18 Pro, on macOS 13 or later. End users need no Python, Node.js or Terminal commands.

The solution retains daily manual tokens, Employee ID, Full Name, the three business use cases, coordinate-based state detection with manual fallback, single/bulk customers, XLSX results and history, map preview and usage reports. Audit downloads include employee details and use case. The Mac SOP is available in the app and supplied as a self-contained HTML file with the shared interface screenshots.

This source contains a native macOS build process and a separate signed/notarized release process. It replaces the earlier Windows-assembled app ZIP and its blocked `.command` launcher. No completed signed release is included in this source archive.

See [BUILD_MACOS.md](BUILD_MACOS.md) for native builds and Apple signing configuration. GitHub Actions can build the app on an Apple Silicon runner. The production build needs a Developer ID Application certificate and Apple notarization credentials; store them in GitHub Actions secrets or the builder's keychain.

Users receive the generated app ZIP, extract it on their Mac and open `Know Your Nzone Manual Token.app`. Developers work from this source archive. History is stored in the user's macOS Application Support folder and the token remains in session memory.
