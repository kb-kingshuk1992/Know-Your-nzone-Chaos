'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const {buildGuide}=require('./build-guide.cjs');
const root=__dirname,mode=process.env.MAC_RELEASE_MODE||'development';
const appName='Know Your Nzone Manual Token',runtime='44.5.1';
async function build(){
  if(process.platform!=='darwin'||process.arch!=='arm64')throw Error('Build on an Apple Silicon Mac or the supplied macos-15 GitHub runner. No Windows cross-build is used.');
  if(!['development','signed'].includes(mode))throw Error('MAC_RELEASE_MODE must be development or signed.');
  for(const file of ['main.cjs','server.cjs','Nozne_master_CSV_PBIX.csv','MMI Nzone Layers 2026_04_23.xlsx','india_states_simplified.geojson'])if(!fs.existsSync(path.join(root,file)))throw Error('Required source asset missing: '+file);
  if(mode==='signed'){
    for(const name of ['MAC_SIGN_IDENTITY','APPLE_TEAM_ID'])if(!process.env[name])throw Error('Signed release requires '+name+'.');
    if(!process.env.MAC_SIGN_IDENTITY.startsWith('Developer ID Application:'))throw Error('Use a Developer ID Application signing identity.');
    if(!process.env.NOTARY_KEYCHAIN_PROFILE&&(!process.env.APPLE_ID||!process.env.APPLE_APP_SPECIFIC_PASSWORD))throw Error('Provide a notary keychain profile or Apple ID and app-specific password for notarization.');
  }
  buildGuide();
  const {packager}=await import('@electron/packager');
  const options={dir:root,out:path.join(root,'dist'),name:appName,executableName:appName,platform:'darwin',arch:'arm64',electronVersion:runtime,appBundleId:'com.knowyournzone.manualtoken.macos',appVersion:'1.1.0',appCategoryType:'public.app-category.business',asar:true,prune:true,overwrite:true,
    ignore:[/[/\\](?:dist|sop_assets|\.github|\.git|\.pnpm|data|output|ui-test-data|test-temp)(?:[/\\]|$)/,/[/\\](?:tests\.cjs|README\.md|BUILD_MACOS\.md|START_HERE\.txt|build-macos\.cjs|build-guide\.cjs|guide-template\.html|entitlements\.mac\.plist|package-lock\.json|pnpm-lock\.yaml)$/],
    extendInfo:{LSMinimumSystemVersion:'13.0'},
    osxSign:{identity:mode==='signed'?process.env.MAC_SIGN_IDENTITY:'-',identityValidation:mode==='signed',hardenedRuntime:true,preAutoEntitlements:false,gatekeeperAssess:false,optionsForFile:()=>({entitlements:path.join(root,'entitlements.mac.plist')})}
  };
  if(mode==='signed')options.osxNotarize=process.env.NOTARY_KEYCHAIN_PROFILE?{keychainProfile:process.env.NOTARY_KEYCHAIN_PROFILE}:{appleId:process.env.APPLE_ID,appleIdPassword:process.env.APPLE_APP_SPECIFIC_PASSWORD,teamId:process.env.APPLE_TEAM_ID};
  const paths=await packager(options);if(paths.length!==1)throw Error('Expected one Apple Silicon app.');
  const packageDir=paths[0],appPath=path.join(packageDir,appName+'.app');
  execFileSync('/usr/bin/codesign',['--verify','--deep','--strict','--verbose=2',appPath],{stdio:'inherit'});
  if(mode==='signed'){
    execFileSync('/usr/bin/xcrun',['stapler','validate',appPath],{stdio:'inherit'});
    execFileSync('/usr/sbin/spctl',['--assess','--type','execute','--verbose=2',appPath],{stdio:'inherit'});
  }
  fs.copyFileSync(path.join(root,'MacBook_SOP.html'),path.join(packageDir,'MacBook_SOP.html'));
  const start=fs.readFileSync(path.join(root,'START_HERE.txt'),'utf8');
  fs.writeFileSync(path.join(packageDir,'START_HERE.txt'),(mode==='signed'?'SIGNED AND NOTARIZED RELEASE\n':'DEVELOPMENT BUILD FOR OWNER TESTING\nThis build is locally signed, not Apple notarized. macOS may block downloaded copies. It is not a release without security exceptions.\n')+start);
  fs.writeFileSync(path.join(packageDir,'BUILD_STATUS.json'),JSON.stringify({architecture:'arm64',minimum_macos:'13.0',electron:runtime,build_host:process.platform,release_mode:mode,developer_id_signed:mode==='signed',notarized:mode==='signed',signature_verified:true,python_required:false,native_user_launch_tested:false},null,2));
  const zip=path.join(root,'dist',`Know_Your_Nzone_ManualToken_Mac_AppleSilicon_${mode==='signed'?'Signed':'Development'}.zip`);
  execFileSync('/usr/bin/ditto',['-c','-k','--sequesterRsrc',packageDir,zip],{stdio:'inherit'});
  fs.writeFileSync(zip+'.sha256',crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex')+'  '+path.basename(zip)+'\n');
  console.log('Created '+zip);
}
build().catch(e=>{console.error(e.message);process.exitCode=1;});
