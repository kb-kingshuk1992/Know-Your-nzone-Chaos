'use strict';
const fs=require('node:fs'),path=require('node:path');
function buildGuide(){
  let html=fs.readFileSync(path.join(__dirname,'guide-template.html'),'utf8');
  html=html.replace(/src="sop_assets\/([^"/]+\.png)"/g,(_,name)=>'src="data:image/png;base64,'+fs.readFileSync(path.join(__dirname,'sop_assets',name)).toString('base64')+'"');
  fs.writeFileSync(path.join(__dirname,'MacBook_SOP.html'),html);
}
if(require.main===module)buildGuide();module.exports={buildGuide};
