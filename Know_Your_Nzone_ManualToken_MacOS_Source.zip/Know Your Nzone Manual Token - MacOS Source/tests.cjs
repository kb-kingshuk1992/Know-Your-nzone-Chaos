'use strict';
const {test,before,after}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const os=require('node:os');
const ExcelJS=require('exceljs');const {createServer,polygonContains,USE_CASES,weekOf}=require('./server.cjs');
let backend,dir,calls=0;
const session={employee_id:'E101',full_name:'Test User',use_case:USE_CASES[1],access_token:'test-token-never-written-123456'};
const row=(id='10001')=>({customer_id:id,customer_name:'Test Customer',lat:26.9124,lon:75.7873});
async function json(route,payload){const r=await fetch(backend.url+route,payload===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});return {status:r.status,data:await r.json()};}
before(async()=>{dir=fs.mkdtempSync(path.join(os.tmpdir(),'kyn-js-test-'));backend=await createServer({dataDir:dir,apiCall:async(c,t)=>{calls++;assert.equal(t,session.access_token);if(c.customer_id==='EMPTY'){const e=Error('No Nzone found');e.noNzone=true;throw e;}if(c.customer_id==='DENIED')throw Error('The access token was rejected or has expired.');return {src_sap_nzone:'TEST001',src_nzoneid:'T1',src_nzone_nme:'Test Nzone',src_state_name:'RAJASTHAN'};}});});
after(async()=>{await backend.close();fs.rmSync(dir,{recursive:true,force:true});});
test('process requires active session and session validates audit fields',async()=>{
  assert.equal((await json('/api/process',{customers:[row()]})).status,400);
  assert.equal((await json('/api/session',{...session,employee_id:''})).status,400);
  assert.equal((await json('/api/session',{...session,use_case:'Wrong'})).status,400);
  assert.equal((await json('/api/session',session)).status,200);
});
test('automatic state detection and both manual fallback paths',()=>{
  assert.equal(backend.normalize(row()).state_name,'RAJASTHAN');assert.equal(backend.normalize(row()).state_identification,'Automatic from coordinates');
  assert.equal(backend.normalize({...row(),lat:0,lon:0}).status,'Manual state required');
  assert.equal(backend.normalize({...row(),manual_state_override:true,state_name:'GUJARAT'}).state_name,'GUJARAT');
  assert.equal(backend.normalize({...row(),lat:''}).valid,false);
});
test('polygon holes and boundary inclusion; ISO week year rollover',()=>{
  const p=[[[0,0],[10,0],[10,10],[0,10],[0,0]],[[3,3],[7,3],[7,7],[3,7],[3,3]]];
  assert.equal(polygonContains(1,1,p),true);assert.equal(polygonContains(5,5,p),false);assert.equal(polygonContains(0,5,p),true);assert.equal(weekOf('2021-01-01'),'2020-W53');
});
test('XLSX template and upload keep numeric coordinates and optional state',async()=>{
  let r=await fetch(backend.url+'/api/template');let b=new ExcelJS.Workbook();await b.xlsx.load(Buffer.from(await r.arrayBuffer()));assert.equal(b.worksheets[0].getCell('C2').value,27.040839);
  b=new ExcelJS.Workbook();const s=b.addWorksheet('Input');s.addRow(['Customer ID','Customer Name','Lat','Lon']);s.addRow(['20001','Bulk',26.9124,75.7873]);
  const data=await b.xlsx.writeBuffer();const form=new FormData();form.append('file',new Blob([data]),'batch.xlsx');r=await fetch(backend.url+'/api/upload',{method:'POST',body:form});assert.equal(r.status,200);const payload=await r.json();assert.equal(payload.customers[0].lat,26.9124);assert.equal(payload.customers[0].state_name,'RAJASTHAN');
});
test('success, duplicate prevention and downloaded result has identity and numbers',async()=>{
  const {data}=await json('/api/process',{customers:[row(),row()]});assert.equal(data.results[0].status,'Success');assert.equal(data.results[1].status,'Re-hit blocked');assert.equal(calls,1);
  const r=await fetch(backend.url+data.download_url),b=new ExcelJS.Workbook();await b.xlsx.load(Buffer.from(await r.arrayBuffer()));const s=b.worksheets[0];assert.equal(s.getCell('A2').value,'E101');assert.equal(s.getCell('B2').value,'Test User');assert.equal(s.getCell('C2').value,USE_CASES[1]);assert.equal(s.getCell('I2').value,26.9124);
  assert.equal((await json('/api/process',{customers:[row()]})).data.results[0].status,'Re-hit blocked');assert.equal(calls,1);
});
test('no Nzone requests manual state; rejected token remains error',async()=>{
  const {data}=await json('/api/process',{customers:[row('EMPTY'),row('DENIED')]});assert.equal(data.results[0].status,'Manual state required');assert.equal(data.results[0].manual_state_required,true);assert.match(data.results[0].remark,/Enter the state manually/);assert.equal(data.results[1].status,'Error');assert.match(data.results[1].error,/expired/);
});
test('admin includes time, state, employee and use case audit sheets; token never persisted',async()=>{
  const r=await fetch(backend.url+'/api/admin-report'),b=new ExcelJS.Workbook();await b.xlsx.load(Buffer.from(await r.arrayBuffer()));assert.equal(b.worksheets.length,10);
  const audit=b.getWorksheet('Successful Customers');assert.equal(audit.getCell('A2').value,'E101');assert.equal(audit.getCell('B2').value,'Test User');assert.equal(audit.getCell('C2').value,USE_CASES[1]);
  const ledger=fs.readFileSync(path.join(dir,'customer_hit_ledger.json'),'utf8');assert.ok(!ledger.includes(session.access_token));assert.ok(!ledger.includes('access_token'));
  const status=(await json('/api/token-status')).data;assert.equal(status.mtd_cost_summary.total_hits,1);assert.equal(status.mtd_cost_summary.total_cost_inr,.1);assert.ok(!JSON.stringify(status).includes(session.access_token));
});
test('SOP endpoint matches Mac guide exactly',async()=>{
  const r=await fetch(backend.url+'/api/user-guide');assert.equal(r.status,200);assert.deepEqual(Buffer.from(await r.arrayBuffer()),fs.readFileSync(path.join(__dirname,'MacBook_SOP.html')));
});
test('rejects external origins and output path traversal',async()=>{
  const r=await fetch(backend.url+'/api/session/clear',{method:'POST',headers:{Origin:'https://example.com','Content-Type':'application/json'},body:'{}'});assert.equal(r.status,403);
  assert.equal((await fetch(backend.url+'/api/results/invalid.xlsx')).status,404);
});
test('restart clears session, retains history and prevents paid re-hit',async()=>{
  await backend.close();backend=await createServer({dataDir:dir,apiCall:async()=>{throw Error('Must not call for prior success');}});
  assert.equal((await json('/api/token-status')).data.session_configured,false);await json('/api/session',session);
  assert.equal((await json('/api/process',{customers:[row()]})).data.results[0].status,'Re-hit blocked');
  await json('/api/session/clear',{});assert.equal((await json('/api/token-status')).data.has_token,false);
});
