'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const http=require('node:http');
const https=require('node:https');
const {randomUUID}=require('node:crypto');
const ExcelJS=require('exceljs');
const {parse}=require('csv-parse/sync');
const Busboy=require('busboy');
const USE_CASES=['Non-Trade Team - Lat/Lon Based Nzone','FleetX - Customer Lat/Lon to Nzone','FleetX - Unloading Lat/Lon to Nzone'];
const INPUT=['Customer ID','Customer Name','Lat','Lon','State Name'];
const FIELDS=[['Employee ID','employee_id'],['Full Name','full_name'],['Use Case','use_case'],['Customer ID','customer_id'],['Customer Name','customer_name'],['State Name','state_name'],['State Identification','state_identification'],['Remark','remark'],['Lat','lat'],['Lon','lon'],['Dataset Source','dataset_source'],['Nzone Code','nzone_code'],['Nzone ID','nzone_id'],['Nzone Name','nzone_name'],['State','state'],['District','district'],['Taluka','taluka'],['City','city'],['Postal Code','postal_code'],['Nzone Area','nzone_area'],['Nzone Type','nzone_type'],['Nzone Subtype','nzone_subtype'],['Status','status'],['Processed On','processed_on'],['Error','error']];
const HISTORY=FIELDS.filter(([_,key])=>['employee_id','full_name','use_case','customer_id','customer_name','state_name','lat','lon','nzone_code','nzone_name','processed_on'].includes(key));
const key=v=>String(v??'').trim().toUpperCase().replace(/\s+/g,' ');
const text=v=>String(v??'').trim();
const number=v=>v===null||v===undefined||text(v)===''?null:(Number.isFinite(Number(v))?Number(v):null);
const aliases={'CHHATTISGARH':'CHATTISGARH','ANDAMAN AND NICOBAR ISLANDS':'ANDAMAN AND NICOBAR','DADRA AND NAGAR HAVELI AND DAMAN AND DIU':'DADRA & NAGAR HAVELI'};
const stateKey=v=>aliases[key(v)]||key(v);
function stamp(d=new Date()){return new Intl.DateTimeFormat('sv-SE',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d);}
function ringContains(lon,lat,ring){
  let inside=false; if(ring.length<3)return false;
  for(let i=0,j=ring.length-1;i<ring.length;j=i++){
    const [x1,y1]=ring[j], [x2,y2]=ring[i];
    const cross=(lon-x1)*(y2-y1)-(lat-y1)*(x2-x1);
    if(Math.abs(cross)<=1e-10 && lon>=Math.min(x1,x2)-1e-10 && lon<=Math.max(x1,x2)+1e-10 && lat>=Math.min(y1,y2)-1e-10 && lat<=Math.max(y1,y2)+1e-10)return true;
    if((y1>lat)!==(y2>lat) && lon<(x2-x1)*(lat-y1)/(y2-y1)+x1)inside=!inside;
  }return inside;
}
function polygonContains(lon,lat,p){return p.length>0 && ringContains(lon,lat,p[0]) && !p.slice(1).some(r=>ringContains(lon,lat,r));}
function classification(id){return text(id).startsWith('1')?'Dealer counter':text(id).startsWith('2')?'Retailer counter':'Unclassified customer';}
function weekOf(day){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+4-(d.getUTCDay()||7));const year=d.getUTCFullYear();return `${year}-W${String(Math.ceil((((d-new Date(Date.UTC(year,0,1)))/86400000)+1)/7)).padStart(2,'0')}`;}
function sheet(book,name,headers,rows){
  const s=book.addWorksheet(name);s.addRow(headers);for(const row of rows)s.addRow(row.map(v=>v??''));
  s.getRow(1).eachCell(c=>{c.font={bold:true,color:{argb:'FFFFFFFF'}};c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF0F766E'}};});
  s.views=[{state:'frozen',ySplit:1}];s.autoFilter={from:{row:1,column:1},to:{row:1,column:headers.length}};
  s.columns.forEach(c=>{let w=12;c.eachCell({includeEmpty:false},cell=>{w=Math.max(w,String(cell.value??'').length+2);});c.width=Math.min(w,36);});return s;
}
async function loadAssets(assetDir){
  const workbook=new ExcelJS.Workbook();await workbook.xlsx.readFile(path.join(assetDir,'MMI Nzone Layers 2026_04_23.xlsx'));
  const s=workbook.worksheets[0], headers=s.getRow(1).values.map(v=>text(v).toLowerCase());
  const codeI=headers.indexOf('state code (as per s4)'),nameI=headers.indexOf('state name (as per s4)'),layerI=headers.indexOf('nzone layer name');
  if([codeI,nameI,layerI].some(i=>i<0))throw Error('Nzone layer workbook headers are invalid.');
  const layers=new Map();s.eachRow((r,n)=>{if(n>1 && text(r.getCell(layerI).value)){const name=stateKey(r.getCell(nameI).value);layers.set(name,{code:text(r.getCell(codeI).value).replace(/\.0$/,'').padStart(2,'0'),layer:text(r.getCell(layerI).value)});}});
  const collection=JSON.parse(fs.readFileSync(path.join(assetDir,'india_states_simplified.geojson'),'utf8'));
  const boundaries=collection.features.filter(f=>['Polygon','MultiPolygon'].includes(f.geometry?.type)).map(f=>{
    const polys=f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates;
    const bounds=[Infinity,Infinity,-Infinity,-Infinity];
    for(const p of polys)for(const r of p)for(const [x,y] of r){bounds[0]=Math.min(bounds[0],x);bounds[1]=Math.min(bounds[1],y);bounds[2]=Math.max(bounds[2],x);bounds[3]=Math.max(bounds[3],y);}
    return {name:stateKey(f.properties.state_name),polys,bounds};
  }).sort((a,b)=>(a.bounds[2]-a.bounds[0])*(a.bounds[3]-a.bounds[1])-(b.bounds[2]-b.bounds[0])*(b.bounds[3]-b.bounds[1]));
  const master=new Map();for(const r of parse(fs.readFileSync(path.join(assetDir,'Nozne_master_CSV_PBIX.csv')),{columns:true,bom:true,relax_column_count:true,skip_empty_lines:true})){
    const code=text(r['Transport Zone']||r.src_sap_nzone);if(!code)continue;
    master.set(code,{nzone_name:r.nzone_nme||r['Transport Zone Name'],state:r['State Name'],district:r['District name'],taluka:r['Taluka Name'],city:r['City Name'],postal_code:r['Postal Code']||r.nzone_pin,nzone_area:r.nzone_area,nzone_type:r.nzone_type,nzone_subtype:r.nzone_subtype});
  }return {layers,boundaries,master};
}
function normalize(row,n,assets){
  const customer_id=text(row['Customer ID']??row.customer_id),customer_name=text(row['Customer Name']??row.customer_name);
  const lat=number(row.Lat??row.lat),lon=number(row.Lon??row.lon), supplied=stateKey(row['State Name']??row.state_name);
  let manual=Boolean(row.manual_state_override||row['Manual State Override']);
  let state_name='',state_identification='',remark='',manual_state_required=false;const errors=[];
  if(!customer_id)errors.push('Customer ID is required');
  if(lat===null||lat< -90||lat>90)errors.push('Lat must be between -90 and 90');
  if(lon===null||lon< -180||lon>180)errors.push('Lon must be between -180 and 180');
  const validLocation=lat!==null&&lon!==null&&Math.abs(lat)<=90&&Math.abs(lon)<=180;
  let detected;
  if(validLocation&&!manual)detected=assets.boundaries.find(b=>lon>=b.bounds[0]&&lat>=b.bounds[1]&&lon<=b.bounds[2]&&lat<=b.bounds[3]&&b.polys.some(p=>polygonContains(lon,lat,p)));
  if(detected){state_name=detected.name;state_identification='Automatic from coordinates';}
  else if(supplied){state_name=supplied;manual=true;state_identification='Manual fallback';remark='Automatic state identification was unavailable or overridden. The supplied state is being used.';}
  else if(validLocation){manual_state_required=true;state_identification='Manual state required';remark='State could not be identified from the coordinates. Enter the state manually and retry.';errors.push('State could not be identified from the supplied coordinates');}
  const mapping=assets.layers.get(state_name);
  if(state_name&&!mapping){errors.push(`No Nzone layer found for state '${state_name}'`);manual_state_required=true;remark='No layer was found for the identified state. Enter a supported state manually and retry.';}
  return {row_number:n,customer_id,customer_name,lat,lon,state_name,state_code:mapping?.code||'',dataset_source:mapping?.layer||'',state_identification,remark,manual_state_override:manual,manual_state_required,status:manual_state_required?'Manual state required':'',valid:errors.length===0,error:errors.join('; ')};
}
function mappls(customer,token){
  const url=new URL('https://mgis-apiv2.mappls.com/dqv/query_apply/join');
  for(const [k,v] of Object.entries({queryType:'spatialOperation',datasetSource:customer.dataset_source,operator:'intersects',sourceProperty:'geom',userGeom:'true'}))url.searchParams.set(k,v);
  const data=JSON.stringify({geometry:{type:'FeatureCollection',features:[{type:'Feature',properties:{},geometry:{type:'Point',coordinates:[customer.lon,customer.lat]}}]}});
  return new Promise((resolve,reject)=>{
    const req=https.request(url,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}},res=>{
      const chunks=[];let size=0;res.on('data',c=>{size+=c.length;if(size>8*1024*1024){req.destroy(Error('API response too large'));return;}chunks.push(c);});
      res.on('end',()=>{if([401,403].includes(res.statusCode))return reject(Error('The access token was rejected or has expired. Update the session token and retry.'));if(res.statusCode<200||res.statusCode>=300)return reject(Error(`API HTTP error ${res.statusCode}`));try{const b=JSON.parse(Buffer.concat(chunks));if(!b.success)return reject(Error(b.message||'Mappls API did not return success'));if(!b.data?.length){const e=Error('No Nzone found for this point');e.noNzone=true;return reject(e);}resolve(b.data[0]);}catch{reject(Error('API returned an invalid response'));}});
    });req.setTimeout(30000,()=>req.destroy(Error('API request timed out. Retry this row.')));req.on('error',reject);req.end(data);
  });
}
async function createServer({assetDir=__dirname,dataDir=path.join(os.homedir(),'Library','Application Support','Know Your Nzone Manual Token JavaScript'),apiCall=mappls,port=0}={}){
  const assets=await loadAssets(assetDir);fs.mkdirSync(dataDir,{recursive:true});const outputDir=path.join(dataDir,'output');fs.mkdirSync(outputDir,{recursive:true});
  const ledgerFile=path.join(dataDir,'customer_hit_ledger.json');let ledger={};
  if(fs.existsSync(ledgerFile)){ledger=JSON.parse(fs.readFileSync(ledgerFile,'utf8'));if(!ledger||typeof ledger!=='object'||Array.isArray(ledger))throw Error('Local history is invalid. Contact support; history has been preserved.');}
  let session={},busy=false;
  const ready=()=>['employee_id','full_name','use_case','access_token'].every(k=>session[k]);
  function checkpoint(){const tmp=ledgerFile+'.tmp';fs.writeFileSync(tmp,JSON.stringify(ledger,null,2),{mode:0o600});fs.renameSync(tmp,ledgerFile);}
  const identity=()=>({employee_id:session.employee_id||'',full_name:session.full_name||'',use_case:session.use_case||''});
  const save=async(book,label)=>{const filename=`${label}_${randomUUID()}.xlsx`;await book.xlsx.writeFile(path.join(outputDir,filename));return filename;};
  function mtd(){const month=stamp().slice(0,7),groups=new Map();for(const r of Object.values(ledger)){if(r.processed_on?.startsWith(month))groups.set(r.state_name,(groups.get(r.state_name)||0)+1);}const states=[...groups].sort().map(([state_name,hits])=>({state_name,hits,cost_inr:Number((hits*.1).toFixed(2))}));const total_hits=states.reduce((a,s)=>a+s.hits,0);return {month,cost_per_hit_inr:.1,total_hits,total_cost_inr:Number((total_hits*.1).toFixed(2)),states};}
  function json(res,value,status=200){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
  function file(res,filename,name){const mime=name.endsWith('.xlsx')?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':name.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream';res.writeHead(200,{'Content-Type':mime,'Content-Disposition':`attachment; filename="${name}"`,'Cache-Control':'no-store'});res.end(fs.readFileSync(filename));}
  async function body(req){const chunks=[];let length=0;for await(const c of req){length+=c.length;if(length>25*1024*1024)throw Error('Request exceeds 25 MB. Split the file into smaller batches.');chunks.push(c);}return Buffer.concat(chunks);}
  async function upload(req){
    const raw=await body(req);return new Promise((resolve,reject)=>{let bb;try{bb=Busboy({headers:req.headers,limits:{files:1,fileSize:20*1024*1024}});}catch(e){return reject(e);}let uploaded,issue;bb.on('file',(field,stream,info)=>{if(field!=='file'||!info.filename.toLowerCase().endsWith('.xlsx'))issue=Error('Upload an XLSX file.');const chunks=[];stream.on('data',c=>chunks.push(c));stream.on('limit',()=>issue=Error('Excel file exceeds 20 MB. Split the batch.'));stream.on('end',()=>uploaded=Buffer.concat(chunks));});bb.on('error',reject);bb.on('close',()=>issue?reject(issue):uploaded?resolve(uploaded):reject(Error('Upload an Excel file.')));bb.end(raw);});
  }
  function adminWorkbook(){
    const book=new ExcelJS.Workbook(),rows=Object.values(ledger).sort((a,b)=>key(a.customer_id).localeCompare(key(b.customer_id)));
    const summaryHeaders=['Successful Hits','Dealers','Retailers','Unclassified','Cost INR'];
    const count=rs=>[rs.length,rs.filter(r=>classification(r.customer_id)==='Dealer counter').length,rs.filter(r=>classification(r.customer_id)==='Retailer counter').length,rs.filter(r=>classification(r.customer_id)==='Unclassified customer').length,Number((rs.length*.1).toFixed(2))];
    sheet(book,'Report Summary',['Metric','Value'],[['Generated On',stamp()],['Total Successful Hits',rows.length],['Distinct Employees',new Set(rows.map(r=>r.employee_id)).size],['Distinct Use Cases',new Set(rows.map(r=>r.use_case)).size],['Cost Basis','1 successful hit = 0.10 INR'],['Total Cost INR',Number((rows.length*.1).toFixed(2))]]);
    function group(name,headers,getKeys){const groups=new Map();for(const r of rows){const keys=getKeys(r),k=JSON.stringify(keys);if(!groups.has(k))groups.set(k,{keys,rows:[]});groups.get(k).rows.push(r);}sheet(book,name,[...headers,...summaryHeaders],[...groups.values()].sort((a,b)=>JSON.stringify(a.keys).localeCompare(JSON.stringify(b.keys))).map(g=>[...g.keys,...count(g.rows)]));}
    group('Daily Trend',['Date'],r=>[r.processed_on.slice(0,10)]);group('Weekly Trend',['ISO Week'],r=>[weekOf(r.processed_on.slice(0,10))]);group('Monthly Trend',['Month'],r=>[r.processed_on.slice(0,7)]);group('State Wise',['State'],r=>[r.state_name]);group('State Monthly Trend',['State','Month'],r=>[r.state_name,r.processed_on.slice(0,7)]);
    group('Use Case Wise',['Use Case'],r=>[r.use_case]);group('User Wise',['Employee ID','Full Name'],r=>[r.employee_id,r.full_name]);
    group('User Use Case',['Employee ID','Full Name','Use Case'],r=>[r.employee_id,r.full_name,r.use_case]);
    const fields=HISTORY.concat([['Dataset Source','dataset_source']]);
    sheet(book,'Successful Customers',[...fields.map(x=>x[0]),'Customer Type','Day','ISO Week','Month','Cost INR'],rows.map(r=>[...fields.map(x=>r[x[1]]),classification(r.customer_id),r.processed_on.slice(0,10),weekOf(r.processed_on.slice(0,10)),r.processed_on.slice(0,7),.1]));return book;
  }
  const server=http.createServer(async(req,res)=>{
    try{
      const address=server.address(),expected=`127.0.0.1:${address.port}`;
      if(req.headers.host!==expected)return json(res,{error:'Invalid local host'},403);
      if(req.headers.origin && req.headers.origin!==`http://${expected}`)return json(res,{error:'Invalid request origin'},403);
      const url=new URL(req.url,`http://${expected}`),p=url.pathname;
      if(req.method==='GET'){
        if(p==='/api/app-info')return json(res,{app:'Know Your Nzone - Manual Token',ok:true,runtime:'JavaScript',python_required:false});
        if(p==='/api/token-status')return json(res,{today:stamp().slice(0,10),...identity(),session_configured:Boolean(ready()),has_token:Boolean(session.access_token),token_mode:'manual_session',state_layer_count:assets.layers.size,state_boundary_count:assets.boundaries.length,mtd_cost_summary:mtd()});
        if(p==='/api/user-guide')return file(res,path.join(assetDir,'MacBook_SOP.html'),'MacBook_SOP.html');
        if(p==='/api/template'){const b=new ExcelJS.Workbook();const s=sheet(b,'Input',INPUT,[['10000001','Sample Dealer',27.040839,77.464148,'']]);s.getCell('E1').note='Optional. Leave blank for automatic state identification; use only as fallback.';return file(res,path.join(outputDir,await save(b,'template')),'nzone_input_template.xlsx');}
        if(p==='/api/history'){const b=new ExcelJS.Workbook();sheet(b,'Successful Customers',HISTORY.map(x=>x[0]),Object.values(ledger).map(r=>HISTORY.map(x=>r[x[1]])));return file(res,path.join(outputDir,await save(b,'history')),'successful_customer_history.xlsx');}
        if(p==='/api/admin-report')return file(res,path.join(outputDir,await save(adminWorkbook(),'admin')),'admin_success_trend_report.xlsx');
        if(p.startsWith('/api/results/')){const name=decodeURIComponent(p.slice('/api/results/'.length));if(path.basename(name)!==name||!/^results_[a-f0-9-]+\.xlsx$/.test(name))return json(res,{error:'Invalid output file'},404);const f=path.join(outputDir,name);if(!fs.existsSync(f))return json(res,{error:'Result file not found'},404);return file(res,f,'nzone_lookup_results.xlsx');}
        const staticPath=p==='/'?'index.html':p.startsWith('/static/')?decodeURIComponent(p.slice(8)):null;
        if(staticPath){const base=path.join(assetDir,'static'),f=path.resolve(base,staticPath);if(!f.startsWith(base+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile())return json(res,{error:'Not found'},404);const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}[path.extname(f)]||'application/octet-stream';res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store'});return res.end(fs.readFileSync(f));}
        return json(res,{error:'Not found'},404);
      }
      if(req.method!=='POST')return json(res,{error:'Method not allowed'},405);
      if(p==='/api/upload'){
        const b=new ExcelJS.Workbook();await b.xlsx.load(await upload(req));const s=b.worksheets[0];if(!s)throw Error('Workbook has no worksheet.');
        const headers=s.getRow(1).values.map(v=>text(v).toLowerCase()),missing=INPUT.slice(0,4).filter(h=>!headers.includes(h.toLowerCase()));if(missing.length)throw Error('Missing required column(s): '+missing.join(', '));
        const customers=[];s.eachRow((row,n)=>{if(n===1)return;const input={};for(const h of INPUT){const i=headers.indexOf(h.toLowerCase());if(i>0){const v=row.getCell(i).value;input[h]=v&&typeof v==='object'?(v.result??v.text??(v.richText?.map(t=>t.text).join('')||'')):v;}}if(Object.values(input).some(v=>v!==null&&text(v)!==''))customers.push(normalize(input,n,assets));});if(!customers.length)throw Error('No input rows found.');return json(res,{customers});
      }
      const payload=JSON.parse((await body(req)).toString()||'{}');
      if(p==='/api/session'||p==='/api/session/clear'){
        if(busy)return json(res,{error:'Wait for the current batch to finish before changing session.'},409);
        if(p.endsWith('/clear'))session={};else{
          if(!text(payload.employee_id))throw Error('Employee ID is required.');if(!text(payload.full_name))throw Error('Full Name is required.');if(!USE_CASES.includes(payload.use_case))throw Error('Select one of the available use cases.');if(text(payload.access_token).length<20)throw Error('Enter a valid Mappls access token.');
          session=Object.fromEntries(['employee_id','full_name','use_case','access_token'].map(k=>[k,text(payload[k])]));
        }return json(res,{ok:true,...identity(),session_configured:Boolean(ready()),has_token:Boolean(session.access_token)});
      }
      if(p==='/api/customer')return json(res,{customer:normalize(payload,1,assets)});
      if(p==='/api/process'){
        if(!ready())throw Error('Complete Employee ID, Full Name, Use Case, and Access Token before processing.');if(busy)return json(res,{error:'A batch is already running. Wait for completion.'},409);if(!Array.isArray(payload.customers)||!payload.customers.length)throw Error('No customer rows to process.');
        busy=true;const context={...session},results=[];
        try{
          for(let i=0;i<payload.customers.length;i++){
            const c={...normalize(payload.customers[i],i+1,assets),employee_id:context.employee_id,full_name:context.full_name,use_case:context.use_case};let result={...c};
            if(!c.valid)result.status=c.manual_state_required?'Manual state required':'Error';
            else if(ledger[key(c.customer_id)]){result.status='Re-hit blocked';result.error=`Re-hit blocked: customer was already processed on ${ledger[key(c.customer_id)].processed_on}.`;}
            else try{
              const r=await apiCall(c,context.access_token),code=text(r.src_sap_nzone),m=assets.master.get(code)||{};
              Object.assign(result,{nzone_code:code,nzone_id:r.src_nzoneid,status:'Success',processed_on:stamp(),error:''});
              for(const field of ['nzone_name','state','district','taluka','city','postal_code','nzone_area','nzone_type','nzone_subtype']){const apiKey={nzone_name:'src_nzone_nme',state:'src_state_name',district:'src_district_name',taluka:'src_taluka_name',city:'src_city_name'}[field]||'src_'+field;result[field]=m[field]||r[apiKey]||'';}
              const audit={};for(const [_,f] of HISTORY.concat([['Layer','dataset_source']]))audit[f]=result[f];ledger[key(c.customer_id)]=audit;checkpoint();
            }catch(e){result.status=e.noNzone?'Manual state required':'Error';result.error=e.message;if(e.noNzone){result.manual_state_required=true;result.remark=`The state was identified as ${c.state_name}, but the API returned no Nzone. Enter the state manually and retry.`;}}
            results.push(result);
          }
          const b=new ExcelJS.Workbook();sheet(b,'Results',FIELDS.map(x=>x[0]),results.map(r=>FIELDS.map(x=>r[x[1]])));const filename=await save(b,'results');return json(res,{results,download_url:'/api/results/'+filename});
        }finally{busy=false;}
      }
      return json(res,{error:'Not found'},404);
    }catch(e){if(!res.headersSent)json(res,{error:e.message||'Request failed'},400);else res.end();}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
  return {server,url:`http://127.0.0.1:${server.address().port}`,assets,isBusy:()=>busy,normalize:r=>normalize(r,1,assets),close:()=>{session={};server.closeAllConnections();return new Promise(resolve=>server.close(resolve));}};
}
module.exports={createServer,loadAssets,normalize,ringContains,polygonContains,USE_CASES,weekOf};
if(require.main===module)createServer({dataDir:process.env.KYN_DATA_DIR}).then(s=>console.log('App listening at '+s.url)).catch(e=>{console.error(e.message);process.exit(1);});
